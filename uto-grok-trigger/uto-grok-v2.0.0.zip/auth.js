var _AUTH_GAS_URL = 'https://script.google.com/macros/s/AKfycbzoyKgZzUhORl6Pdf-WQKQcaKoVA7eJAYmn-0tpV3xJS3gF6_fD17MmBTLG6K8nFEW4rA/exec';

function doAuth() {
  var course = document.getElementById('authCourse').value;
  var nick = document.getElementById('authNick').value.trim();
  var pw = document.getElementById('authPw').value.trim();
  var errEl = document.getElementById('authErr');
  var btn = document.getElementById('authBtn');
  var applyBox = document.getElementById('authApplyBox');

  applyBox.style.display = 'none';
  errEl.style.display = 'none';

  if (!course) { errEl.textContent = '강의를 선택해주세요'; errEl.style.display = 'block'; return; }
  if (!nick) { errEl.textContent = '닉네임을 입력해주세요'; errEl.style.display = 'block'; return; }
  if (!pw) { errEl.textContent = '비밀번호를 입력해주세요'; errEl.style.display = 'block'; return; }

  btn.textContent = '확인 중...';
  btn.disabled = true;

  var url = _AUTH_GAS_URL + '?action=login&nickname=' + encodeURIComponent(nick) + '&password=' + encodeURIComponent(pw) + '&course=' + encodeURIComponent(course) + '&source=extension';
  fetch(url)
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.success) {
        chrome.storage.local.set({ authNick: nick, authCourse: course, authTime: Date.now() });
        document.getElementById('authGate').style.display = 'none';
        document.getElementById('mainApp').style.display = 'block';
      } else {
        if (data.error === 'wrong_password') {
          errEl.textContent = '비밀번호가 올바르지 않습니다';
          errEl.style.display = 'block';
        } else if (data.error === 'not_found') {
          applyBox.style.display = 'flex';
        } else {
          errEl.textContent = '오류가 발생했습니다';
          errEl.style.display = 'block';
        }
      }
      btn.textContent = '입장하기';
      btn.disabled = false;
    })
    .catch(function() {
      errEl.textContent = '서버 연결 실패. 잠시 후 다시 시도해주세요.';
      errEl.style.display = 'block';
      btn.textContent = '입장하기';
      btn.disabled = false;
    });
}

function doAuthApply() {
  var course = document.getElementById('authCourse').value;
  var nick = document.getElementById('authNick').value.trim();
  var applyBtn = document.getElementById('authApplyBtn');
  var applyMsg = document.getElementById('authApplyMsg');

  if (!nick) return;
  applyBtn.textContent = '신청 중...';
  applyBtn.disabled = true;

  var url = _AUTH_GAS_URL + '?action=apply&nickname=' + encodeURIComponent(nick) + '&course=' + encodeURIComponent(course) + '&source=extension';
  fetch(url)
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.success) {
        applyMsg.textContent = '✅ 신청 완료! 관리자 승인 후 입장 가능합니다.';
        applyMsg.style.color = 'var(--g4)';
        applyBtn.textContent = '⏳ 승인 대기중';
        applyBtn.disabled = true;
        applyBtn.style.background = '#6B7280';
        applyBtn.style.cursor = 'not-allowed';
      } else if (data.error === 'already_applied') {
        applyMsg.textContent = '이미 신청된 닉네임입니다. 승인을 기다려주세요.';
        applyMsg.style.color = 'var(--wn)';
        applyBtn.textContent = '⏳ 승인 대기중';
        applyBtn.disabled = true;
        applyBtn.style.background = '#6B7280';
        applyBtn.style.cursor = 'not-allowed';
      } else if (data.error === 'already_registered') {
        applyMsg.textContent = '이미 등록된 닉네임입니다. 비밀번호를 확인해주세요.';
        applyMsg.style.color = 'var(--wn)';
      } else {
        applyMsg.textContent = '신청 실패';
        applyMsg.style.color = 'var(--dn)';
      }
      applyMsg.style.display = 'block';
      applyBtn.textContent = '📝 가입 신청하기';
      applyBtn.disabled = false;
    })
    .catch(function() {
      applyMsg.textContent = '서버 연결 실패';
      applyMsg.style.display = 'block';
      applyMsg.style.color = 'var(--dn)';
      applyBtn.textContent = '📝 가입 신청하기';
      applyBtn.disabled = false;
    });
}

// 영구 저장: chrome.storage.local에서 인증 확인
(function() {
  chrome.storage.local.get(['authNick'], function(s) {
    if (s.authNick) {
      document.getElementById('authGate').style.display = 'none';
      document.getElementById('mainApp').style.display = 'block';
    }
  });
})();

// 도움말 버튼 → 매뉴얼 페이지
document.getElementById('helpBtn').addEventListener('click', function() {
  chrome.tabs.create({ url: 'https://moond91.github.io/uto-grok-trigger/' });
});

// 인증 버튼 이벤트 바인딩 (Manifest V3 CSP 대응)
document.getElementById('authBtn').addEventListener('click', doAuth);
document.getElementById('authApplyBtn').addEventListener('click', doAuthApply);
document.getElementById('authApplyClose').addEventListener('click', function() {
  document.getElementById('authApplyBox').style.display = 'none';
});
document.getElementById('authPw').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') doAuth();
});

// 카페 링크 트리거롱폼용으로 오버라이드
var _cafeBtnCheck = setInterval(function() {
  var cafeBtn = document.getElementById('bugModalCafe');
  if (cafeBtn) {
    cafeBtn.addEventListener('click', function(e) {
      e.stopImmediatePropagation();
      chrome.tabs.create({ url: 'https://cafe.naver.com/triggerlongform1/317' });
    }, true);
    clearInterval(_cafeBtnCheck);
  }
}, 100);
