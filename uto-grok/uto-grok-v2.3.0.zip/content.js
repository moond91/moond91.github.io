// ═══════════════════════════════════════════════
//  우토그록 Uto Grok — Content Script v2.3.0
//  FIX: React 호환 클릭으로 업스케일 메뉴 작동
// ═══════════════════════════════════════════════
(()=>{
'use strict';

if (window.__UTOGROK_LISTENER__) return;
window.__UTOGROK_LISTENER__ = true;

let aborted = false;
let isProcessing = false; // ★ 실행 잠금

chrome.runtime.sendMessage({ type: 'TAB_READY' }).catch(()=>{});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'GENERATE') {
    startKeepAlive(); // ★ 창 최소화 방지
    if (isProcessing) {
      log('⚠️ 이미 처리 중 — 중복 무시');
      sendResponse({ success: false, error: 'Already processing' });
      return;
    }
    isProcessing = true;
    aborted = false;
    handleGenerate(msg)
      .then(r => { isProcessing = false; sendResponse(r); })
      .catch(e => { isProcessing = false; sendResponse({ success: false, error: e.message }); });
    return true;
  }
  if (msg.action === 'STOP') {
    aborted = true;
    isProcessing = false;
    sendResponse({ success: true });
  }
});

function step(s) {
  try { chrome.runtime.sendMessage({ type: 'STEP_UPDATE', step: s }); } catch {}
}

// ═══════════════════════════════════════
//  MAIN: 매 생성마다 이 전체 흐름 실행
// ═══════════════════════════════════════
async function handleGenerate({ type, prompt, imageDataUrl, ratio, duration, quality, folder }) {
  log(`=== 새 작업 시작: ${type} ===`);
  if (prompt) log(`프롬프트: ${prompt.substring(0, 50)}...`);

  try {
    // ★ STEP 0: 완전 리셋 — 새로운 Imagine 입력 화면
    step('input');
    await resetToFreshImagine();
    log('✓ 리셋 완료');
    await wait(2000); // 하단 바 완전 로드 대기

    // STEP 1: 비디오 모드 선택
    await clickBottomBarByText('비디오', 'video', 'Video');
    await wait(800); // 모드 전환 후 하단 바 옵션 변경 대기

    // STEP 2: 옵션 설정 (길이, 비율)
    if (duration) {
      const d = duration.replace('-concat', '');
      await clickBottomBarByText(d + 's');
      await wait(200);
    }
    if (ratio) {
      await clickBottomBarByText(ratio);
      await wait(200);
    }

    // STEP 3: 이미지 모드면 이미지 1개 업로드
    if (type === 'image' && imageDataUrl) {
      await uploadSingleImage(imageDataUrl);
      await wait(2000);
    }

    // STEP 4: 프롬프트 입력
    if (prompt) {
      await typePrompt(prompt);
      await wait(500);
    }

    if (aborted) throw new Error('Aborted');

    // STEP 5: 전송
    step('send');
    await waitAndClickSubmit();
    await wait(1000);

    // STEP 6: 동영상 생성 대기
    step('generate');
    const videoUrl = await waitForVideo();
    if (aborted) throw new Error('Aborted');

    // ★ STEP 7: 업스케일 (480p-upscale 또는 720p 선택 시)
    let finalVideoUrl = videoUrl;
    if (quality === '480p-upscale' || quality === '720p') {
      step('download');
      log('🔍 업스케일 시작...');
      const upscaledUrl = await doUpscale();
      if (upscaledUrl) finalVideoUrl = upscaledUrl;
    }

    // STEP 8: 다운로드
    if (quality && quality !== 'none' && finalVideoUrl) {
      step('download');
      await downloadToFolder(finalVideoUrl, prompt || 'video', folder);
    }

    // ★ STEP 8: 뒤로가기 → 새 입력 화면으로 복귀
    await goBackToInput();

    step('done');
    log('✅ 작업 완료!');
    return { success: true, videoUrl };

  } catch (err) {
    step('error');
    log('❌ ' + err.message);
    return { success: false, error: err.message };
  }
}

// ═══════════════════════════════════════
//  ★ 완전 리셋: 새로운 Imagine 페이지로
// ═══════════════════════════════════════
// ═══════════════════════════════════════
//  ★ Imagine 새 입력 페이지로 이동
// ═══════════════════════════════════════
async function goBackToInput() {
  log('⬅️ Imagine 새 페이지로...');

  // ★ Imagine 사이드바 링크 클릭 → 새 입력 페이지
  const imagineLink = document.querySelector('a[href="/imagine"]');
  if (imagineLink) {
    imagineLink.click();
    log('  ✓ Imagine 링크 클릭');
    await wait(2500);

    // 에디터 + 하단 바가 로드될 때까지 대기
    await waitForEl('div.ProseMirror[contenteditable="true"], div[contenteditable="true"]', 10000);
    await wait(1000); // 하단 바 로드 추가 대기
    return;
  }

  // 폴백: 뒤로가기
  const backBtn = document.querySelector('a[aria-label="뒤로가기"]');
  if (backBtn) {
    backBtn.click();
    log('  ✓ 뒤로가기 클릭');
    await wait(2500);
    await waitForEl('div.ProseMirror[contenteditable="true"], div[contenteditable="true"]', 10000);
    await wait(1000);
    return;
  }

  log('  ⚠️ 링크 못찾음 → history.back()');
  window.history.back();
  await wait(3000);
}

// ═══════════════════════════════════════
//  ★ 리셋: 입력 화면 준비
// ═══════════════════════════════════════
async function resetToFreshImagine() {
  log('🔄 리셋...');

  // 에디터가 있는지 확인 (입력 화면인지)
  const editor = document.querySelector('div.ProseMirror[contenteditable="true"]') ||
                 document.querySelector('div[contenteditable="true"]');

  if (!editor) {
    // 입력 화면이 아님 → Imagine 링크 클릭
    log('  입력 화면 아님 → Imagine 이동');
    await goBackToInput();
    await wait(500);
  }

  // 첨부 이미지 제거 + 에디터 비우기
  await removeAttachedImages();
  await wait(300);

  const ed = document.querySelector('div.ProseMirror[contenteditable="true"]') ||
             document.querySelector('div[contenteditable="true"]');
  if (ed) {
    ed.focus();
    await wait(100);
    ed.innerHTML = '<p></p>';
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  log('  ✓ 입력 초기화 완료');
}

// 첨부된 이미지 썸네일들 제거
async function removeAttachedImages() {
  let removed = 0;

  // grok.com의 이미지 썸네일: 입력창 위에 작은 이미지들이 표시됨
  // 썸네일 근처의 X 버튼 또는 삭제 버튼을 반복적으로 클릭

  for (let attempt = 0; attempt < 20; attempt++) {
    // 다양한 제거 버튼 셀렉터
    const selectors = [
      'button[aria-label*="삭제"]',
      'button[aria-label*="Remove"]',
      'button[aria-label*="remove"]',
      'button[aria-label*="Close"]',
      'button[aria-label*="close"]',
      'button[aria-label*="취소"]',
      'button[aria-label*="Delete"]',
      'button[aria-label*="delete"]',
    ];

    let found = false;
    for (const sel of selectors) {
      const btns = document.querySelectorAll(sel);
      for (const btn of btns) {
        const rect = btn.getBoundingClientRect();
        // 화면 하단부(입력 영역 근처)에 있고, 작은 버튼(X 버튼)
        if (rect.width > 0 && rect.width < 40 && rect.height > 0 && rect.y > window.innerHeight * 0.4) {
          btn.click();
          removed++;
          found = true;
          await wait(400);
          break;
        }
      }
      if (found) break;
    }

    // 작은 X 버튼을 못 찾으면 이미지 썸네일 컨테이너 자체에서 찾기
    if (!found) {
      // 입력창 근처의 img 태그 → 그 부모의 버튼 찾기
      const inputArea = document.querySelector('[class*="query-bar"]') ||
                        document.querySelector('div.ProseMirror')?.parentElement?.parentElement;
      if (inputArea) {
        const imgs = inputArea.querySelectorAll('img');
        for (const img of imgs) {
          // 작은 썸네일 이미지 (width < 100px)
          const r = img.getBoundingClientRect();
          if (r.width > 0 && r.width < 100) {
            // 이 이미지 근처의 버튼 찾기
            const parent = img.closest('div') || img.parentElement;
            const closeBtn = parent?.querySelector('button');
            if (closeBtn) {
              closeBtn.click();
              removed++;
              found = true;
              await wait(400);
              break;
            }
          }
        }
      }
    }

    if (!found) break;
  }

  if (removed > 0) log(`  첨부 이미지 ${removed}개 제거`);
}

// ═══════════════════════════════════════
//  ★ 업스케일: ... 메뉴 → 동영상 업스케일
// ═══════════════════════════════════════
async function doUpscale() {
  try {
    // Step 1: ... (더보기) 버튼 찾기 & 클릭
    const moreBtn = findMoreOptionsButton();
    if (!moreBtn) {
      log('  ⚠️ ... 더보기 버튼 못찾음 — 업스케일 건너뜀');
      return null;
    }

    // ★ React 호환 클릭 (PointerEvent + MouseEvent)
    reactClick(moreBtn);
    log('  ✓ 추가 옵션 클릭 (React 호환)');

    // ★ Radix 메뉴 렌더링 대기 — 최대 8초, 0.5초 간격
    let upscaleItem = null;
    for (let retry = 0; retry < 16; retry++) {
      await wait(500);

      // 모든 radix 포탈 확인
      const wrappers = document.querySelectorAll('div[data-radix-popper-content-wrapper]');
      if (retry === 0) log(`  Radix 포탈 ${wrappers.length}개 발견`);

      // role="menu" 확인
      const allMenus = document.querySelectorAll('[role="menu"]');
      if (retry === 0) log(`  role=menu ${allMenus.length}개 발견`);

      // 모든 menuitem 확인
      const allItems = document.querySelectorAll('[role="menuitem"]');
      if (retry === 0) {
        log(`  role=menuitem ${allItems.length}개 발견`);
        allItems.forEach((item, i) => {
          log(`    [${i}] "${(item.textContent||'').trim().substring(0,30)}"`);
        });
      }

      // 업스케일 찾기
      for (const item of allItems) {
        const text = (item.textContent || '').trim();
        if (text.includes('업스케일') || text.includes('Upscale')) {
          upscaleItem = item;
          log(`  ✓ 업스케일 찾음! (retry ${retry}): "${text}"`);
          break;
        }
      }
      if (upscaleItem) break;

      // 2번째 시도에서 다시 클릭 시도
      if (retry === 4) {
        log('  ⚠️ 4회 실패 → 재클릭 (React 호환)');
        reactClick(moreBtn);
      }
    }

    if (!upscaleItem) {
      log('  ⚠️ 동영상 업스케일 메뉴 못찾음 — 건너뜀');
      document.body.click();
      await wait(300);
      return null;
    }

    reactClick(upscaleItem);
    log('  ✓ 동영상 업스케일 클릭 (React 호환)');
    await wait(2000);

    // Step 3: 업스케일 완료 대기
    log('  ⏳ 업스케일 대기...');
    const upscaledUrl = await waitForUpscaleComplete();

    if (upscaledUrl) {
      log('  ✓ 업스케일 완료!');
      return upscaledUrl;
    }

    log('  ℹ️ 업스케일 URL 감지 못함 — 원본으로 진행');
    return null;
  } catch (e) {
    log('  ⚠️ 업스케일 오류: ' + e.message);
    return null;
  }
}

function findMoreOptionsButton() {
  // EXACT: button[aria-label="추가 옵션"] (aria-haspopup="menu")
  const exact = document.querySelector('button[aria-label="추가 옵션"]');
  if (exact) return exact;

  // Fallback: English labels
  const byLabel = document.querySelector(
    'button[aria-label="More options"], button[aria-label="더보기"], button[aria-label="More"]'
  );
  if (byLabel) return byLabel;

  // Fallback: lucide-ellipsis SVG icon
  const svgBtn = document.querySelector('button svg.lucide-ellipsis');
  if (svgBtn) return svgBtn.closest('button');

  return null;
}

async function waitForUpscaleComplete(timeout = 120000) {
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;

    const poll = setInterval(() => {
      if (done || aborted) { clearInterval(poll); resolve(null); return; }
      if (Date.now() - start > timeout) {
        done = true; clearInterval(poll);
        log('  ⚠️ 업스케일 타임아웃 (2분)');
        resolve(null);
        return;
      }

      // 완료 알림 감지
      const successEl = findByText(
        ['업스케일 완료', 'Upscale complete', 'upscaled', '완료'],
        '[class*="toast"], [class*="alert"], [class*="notification"], [role="alert"]'
      );
      if (successEl) {
        done = true; clearInterval(poll);
        const vids = document.querySelectorAll('video');
        for (let i = vids.length - 1; i >= 0; i--) {
          const src = vids[i].src || vids[i].querySelector('source')?.src;
          if (src) { resolve(src); return; }
        }
        resolve(null);
        return;
      }

      // 비디오 src 변경 감지
      const vids = document.querySelectorAll('video');
      for (let i = vids.length - 1; i >= 0; i--) {
        const src = vids[i].src || vids[i].querySelector('source')?.src;
        if (src && !vids[i].dataset._utoUpscaled) {
          vids[i].dataset._utoUpscaled = '1';
          done = true; clearInterval(poll);
          resolve(src);
          return;
        }
      }
    }, 2000);
  });
}

// ═══════════════════════════════════════
//  하단 바 옵션 클릭 (비디오, 6s, 16:9 등)
// ═══════════════════════════════════════
async function clickBottomBarByText(...texts) {
  const els = document.querySelectorAll('button, label, [role="radio"], [role="tab"], span, div');
  for (const el of els) {
    const t = (el.textContent || '').trim();
    for (const text of texts) {
      if (t === text || t.toLowerCase() === text.toLowerCase()) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0 && r.height < 50) {
          el.click();
          log(`  옵션: "${text}"`);
          return true;
        }
      }
    }
  }
  log(`  옵션 못찾음: "${texts[0]}"`);
  return false;
}

// ═══════════════════════════════════════
//  이미지 1개만 업로드
// ═══════════════════════════════════════
async function uploadSingleImage(dataUrl) {
  log('📎 이미지 업로드...');
  const file = toFile(dataUrl, 'upload_image.png');

  // ═══ 방법 1: file input click 가로채기 ═══
  // Upload 버튼 클릭 전에 file input의 click을 오버라이드
  const allFileInputs = document.querySelectorAll('input[type="file"]');
  allFileInputs.forEach(fi => {
    const origClick = fi.click.bind(fi);
    fi.click = function() {
      log('  ✓ file input click 가로챔!');
      const dt = new DataTransfer();
      dt.items.add(file);
      Object.defineProperty(this, 'files', { value: dt.files, writable: true, configurable: true });
      const ev = new Event('change', { bubbles: true });
      Object.defineProperty(ev, 'target', { value: this, writable: false });
      this.dispatchEvent(ev);
      this.dispatchEvent(new Event('input', { bubbles: true }));
      this.click = origClick; // 복원
    };
  });

  const uploadBtn = document.querySelector('button[aria-label="Upload"]');
  if (uploadBtn) {
    uploadBtn.click();
    log('  Upload 버튼 클릭');
    await wait(2000);

    const sub = document.querySelector('button[aria-label="제출"], button[aria-label="Submit"]');
    if (sub && !sub.disabled) { log('  ✓ 업로드 성공! (click intercept)'); return; }
    log('  ⚠️ click intercept 후 전송 비활성화');
  }

  // ═══ 방법 2: drop-container에 드래그앤드롭 ═══
  log('  방법 2: drop-container 드래그앤드롭...');
  const dropTargets = [
    document.querySelector('[data-testid="drop-container"]'),
    document.querySelector('[data-testid="drop-ui"]'),
    document.querySelector('[class*="query-bar"]'),
    document.querySelector('div.ProseMirror[contenteditable="true"]'),
  ].filter(Boolean);

  for (const target of dropTargets) {
    const dt2 = new DataTransfer();
    dt2.items.add(file);
    target.dispatchEvent(new DragEvent('dragenter', { bubbles: true, cancelable: true, dataTransfer: dt2 }));
    await wait(200);
    target.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt2 }));
    await wait(200);
    target.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt2 }));
    await wait(2000);

    const sub2 = document.querySelector('button[aria-label="제출"], button[aria-label="Submit"]');
    if (sub2 && !sub2.disabled) { log('  ✓ 업로드 성공! (drop)'); return; }
  }

  // ═══ 방법 3: 클립보드 붙여넣기 ═══
  log('  방법 3: 클립보드 붙여넣기...');
  const editor = document.querySelector('div.ProseMirror[contenteditable="true"]');
  if (editor) {
    editor.focus();
    await wait(100);
    const dt3 = new DataTransfer();
    dt3.items.add(file);
    editor.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt3 }));
    await wait(2000);

    const sub3 = document.querySelector('button[aria-label="제출"], button[aria-label="Submit"]');
    if (sub3 && !sub3.disabled) { log('  ✓ 업로드 성공! (paste)'); return; }
  }

  log('  ⚠️ 모든 업로드 방식 시도 완료');
}

// ═══════════════════════════════════════
//  프롬프트 입력 (tiptap ProseMirror)
// ═══════════════════════════════════════
async function typePrompt(text) {
  if (!text) return;

  let editor = document.querySelector('div.ProseMirror[contenteditable="true"]');
  if (!editor) editor = document.querySelector('div[contenteditable="true"]');
  if (!editor) throw new Error('프롬프트 입력창을 찾을 수 없습니다.');

  editor.focus();
  await wait(100);

  // 기존 내용에 텍스트 추가 (이미지가 이미 있을 수 있으므로 덮어쓰지 않음)
  // 빈 <p> 태그를 찾아서 텍스트 입력
  const emptyP = editor.querySelector('p.is-empty, p:empty');
  if (emptyP) {
    emptyP.textContent = text;
  } else {
    // 새 p 태그 추가
    const p = document.createElement('p');
    p.textContent = text;
    editor.appendChild(p);
  }

  // React/tiptap에 변경 알림
  editor.dispatchEvent(new InputEvent('input', {
    bubbles: true, cancelable: true, inputType: 'insertText', data: text
  }));
  await wait(100);
  editor.dispatchEvent(new Event('input', { bubbles: true }));

  log(`  프롬프트: "${text.substring(0, 40)}${text.length > 40 ? '...' : ''}"`);
}

// ═══════════════════════════════════════
//  전송 버튼 대기 + 클릭
// ═══════════════════════════════════════
async function waitAndClickSubmit() {
  let btn = null;
  for (let i = 0; i < 60; i++) { // 최대 30초
    btn = document.querySelector('button[aria-label="제출"]') ||
          document.querySelector('button[aria-label="Submit"]') ||
          document.querySelector('button[aria-label="Send"]');
    if (btn && !btn.disabled) break;

    if (aborted) throw new Error('Aborted');
    await wait(500);
    if (i > 0 && i % 10 === 0) log(`  ⏳ 전송 버튼 대기... (${i / 2}초)`);
  }

  if (!btn) throw new Error('전송 버튼을 찾을 수 없습니다.');
  if (btn.disabled) throw new Error('전송 버튼 30초간 비활성화. 이미지가 업로드되었는지 확인해주세요.');

  btn.click();
  log('  ✓ 전송');
}

// ═══════════════════════════════════════
//  동영상 생성 대기
// ═══════════════════════════════════════
async function waitForVideo(timeout = 300000) {
  log('⏳ 동영상 대기...');

  return new Promise((resolve, reject) => {
    const start = Date.now();
    let done = false;

    const obs = new MutationObserver(() => {
      if (done || aborted) { obs.disconnect(); if (aborted) reject(new Error('Aborted')); return; }
      const v = findNewVideo();
      if (v) { done = true; obs.disconnect(); log('  ✓ 동영상 감지!'); resolve(v); }
    });
    obs.observe(document.body, {
      childList: true, subtree: true, attributes: true,
      attributeFilter: ['src', 'href', 'data-state']
    });

    const poll = setInterval(() => {
      if (done || aborted) { clearInterval(poll); return; }
      if (Date.now() - start > timeout) {
        done = true; obs.disconnect(); clearInterval(poll);
        reject(new Error('동영상 생성 시간 초과 (5분)'));
        return;
      }

      // 에러 감지
      const errEl = findByText(
        ['error', 'failed', '오류', '실패', 'rate limit', 'try again'],
        '[class*="error"], [class*="alert"], [role="alert"]'
      );
      if (errEl) {
        done = true; obs.disconnect(); clearInterval(poll);
        reject(new Error('생성 오류: ' + (errEl.textContent || '').substring(0, 100)));
        return;
      }

      const v = findNewVideo();
      if (v) { done = true; obs.disconnect(); clearInterval(poll); log('  ✓ 동영상 감지 (poll)'); resolve(v); }
    }, 2000);
  });
}

function findNewVideo() {
  const vids = document.querySelectorAll('video');
  for (let i = vids.length - 1; i >= 0; i--) {
    const v = vids[i], src = v.src || v.querySelector('source')?.src;
    if (src && !v.dataset._uto) { v.dataset._uto = '1'; return src; }
  }
  const links = document.querySelectorAll('a[href*=".mp4"], a[download]');
  for (let i = links.length - 1; i >= 0; i--) {
    const a = links[i];
    if (!a.dataset._uto) { a.dataset._uto = '1'; return a.href; }
  }
  return null;
}

// ═══════════════════════════════════════
//  하위폴더 다운로드
// ═══════════════════════════════════════
async function downloadToFolder(url, prompt, folder) {
  const slug = (prompt || 'video').substring(0, 40)
    .replace(/[^a-zA-Z0-9가-힣\s]/g, '').replace(/\s+/g, '_').toLowerCase() || 'video';
  const ts = new Date().toISOString().slice(0, 16).replace(/[:-]/g, '');
  const filename = `${folder || 'grok-video'}/${ts}_${slug}.mp4`;

  log(`  📥 다운로드: ${filename}`);
  chrome.runtime.sendMessage({ type: 'DOWNLOAD_VIDEO', url, filename });
  await wait(2000);
}

// ═══════════════════════════════════════
//  유틸리티
// ═══════════════════════════════════════
function findByText(texts, selector) {
  for (const el of document.querySelectorAll(selector)) {
    const et = (el.textContent || '').trim().toLowerCase();
    const al = (el.getAttribute('aria-label') || '').toLowerCase();
    for (const t of texts) {
      const tl = t.toLowerCase();
      if (et === tl || et.includes(tl) || al.includes(tl)) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) return el;
      }
    }
  }
  return null;
}

async function waitForEl(selector, timeout = 10000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el) return el;
    await wait(500);
  }
  return null;
}

function toFile(dataUrl, name) {
  const [h, d] = dataUrl.split(',');
  const mime = h.match(/:(.*?);/)[1];
  const bin = atob(d);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new File([arr], name, { type: mime });
}

// ★ Web Worker 기반 타이머 (창 최소화해도 안 느려짐)
const _wb=new Blob([`self.onmessage=function(e){setTimeout(function(){self.postMessage('done')},e.data)}`],{type:'application/javascript'});
const _wu=URL.createObjectURL(_wb);
function wait(ms){
  return new Promise(resolve=>{
    try{
      const w=new Worker(_wu);
      w.onmessage=()=>{w.terminate();resolve();};
      w.postMessage(ms);
    }catch{setTimeout(resolve,ms);}
  });
}
function log(msg) { console.log(`[UtoGrok] ${msg}`); }

/**
 * ★ React 호환 클릭 — grok.com은 React 기반이라
 * 단순 .click()이나 MouseEvent만으로는 핸들러가 트리거되지 않음.
 * PointerEvent + MouseEvent 조합이 필요.
 */
function reactClick(el) {
  const rect = el.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window };
  el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerId: 1 }));
  el.dispatchEvent(new MouseEvent('mousedown', opts));
  el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerId: 1 }));
  el.dispatchEvent(new MouseEvent('mouseup', opts));
  el.dispatchEvent(new MouseEvent('click', opts));
}

log('Content script v2.3.0 ✅');

// ★ 창 최소화해도 멈추지 않게 무음 오디오 재생
let keepAliveStarted=false;
function startKeepAlive(){
  if(keepAliveStarted)return;
  try{
    const ctx=new AudioContext();
    if(ctx.state==='suspended')ctx.resume();
    const osc=ctx.createOscillator();
    const gain=ctx.createGain();
    gain.gain.value=0.00001;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    keepAliveStarted=true;
    log('🔊 Keep-alive 활성화 (창 최소화 지원)');
  }catch(e){log('⚠️ Keep-alive 실패: '+e.message);}
}
// 페이지 클릭 시에도 활성화 (AudioContext 정책 우회)
document.addEventListener('click',()=>startKeepAlive(),{once:true});
})();
