(function(){var _d4qbo=function(){return void 0;};// ═══════════════════════════════════════════════
//  우토그록 Uto Grok — Side Panel v3.0.0
//  Features 4-17 all included
// ═══════════════════════════════════════════════
const $=id=>document.getElementById(id);
let isRunning=false,isPaused=false,queue=[],currentIndex=0,tabId=null;
let uploadedImages=[],currentMode='image',history=[],genTimes=[],pauseResolve=null;
let presets=[],lang='ko';

// ★ 라이선스 인증 API URL (Google Apps Script 배포 URL로 교체)
const LICENSE_API_URL = atob('aHR0cHM6Ly9zY3JpcHQuZ29vZ2xlLmNvbS9tYWNyb3Mvcy9BS2Z5Y2J6b29aSXVEbVc2WG5rajAzRGV3MTFJY21mcDJNa1IxRUxkWTJHVmF5OW9KSGNkNF9PQ0twQ1UyUTFkczh0OXU5Slp4QS9leGVj');

const DEFAULTS={mode:'frame-to-video',ratio:'16:9',duration:'6',retry:5,quality:'480p',lang:'ko',outputCount:1,folder:'grok-folder-1',delayMin:5,delayMax:10,prompts:'',theme:'dark'};

// DOM
const sDot=$('sDot'),sTxt=$('sTxt'),etaText=$('etaText'),stepBadge=$('stepBadge');
const promptInput=$('promptInput'),promptCount=$('promptCount');
const imgCount=$('imgCount'),imgList=$('imgList'),imgSection=$('imgSection');
const uploadZone=$('uploadZone'),fileInput=$('fileInput');
const outputCount=$('outputCount'),folderName=$('folderName');
const delayMin=$('delayMin'),delayMax=$('delayMax');
const setMode=$('setMode'),setRatio=$('setRatio'),setDuration=$('setDuration'),setRetry=$('setRetry');
const setQuality=$('setQuality'),setLang=$('setLang');
const setDelayMin=$('setDelayMin'),setDelayMax=$('setDelayMax');
const progSec=$('qStatus'),progFill=$('progFill'),progDone=$('progDone'),progPct=$('progPct');
const qStatusTxt=$('qStatusTxt');
const qBody=$('qBody'),qCount=$('qCount');
const runBtn=$('runBtn'),stopBtn=$('stopBtn'),pauseBtn=$('pauseBtn');
const clearBtn=$('clearBtn'),bugBtn=$('bugBtn');
const resetBtn=$('resetBtn'),saveBtn=$('saveBtn'),themeBtn=$('themeBtn');
const exportBtn=$('exportBtn'),importBtn=$('importBtn'),importFile=$('importFile');
const presetName=$('presetName'),presetSaveBtn=$('presetSaveBtn'),presetList=$('presetList');
const csvImportBtn=$('csvImportBtn'),csvFileInput=$('csvFileInput');
const histBody=$('histBody'),histClearBtn=$('histClearBtn');

// ═══════════════════════════════════════
// INIT
// ═══════════════════════════════════════
async function init(){
  // ★ 라이선스 인증 체크
  const authOk = await checkAuth();
  if(!authOk) return; // 인증 안 되면 여기서 멈춤

  const s=await chrome.storage.local.get([...Object.keys(DEFAULTS),'history','presets']);
  if(s.mode)setMode.value=s.mode; if(s.ratio)setRatio.value=s.ratio;
  if(s.duration)setDuration.value=s.duration; if(s.retry)setRetry.value=s.retry;
  if(s.quality)setQuality.value=s.quality; if(s.lang){setLang.value=s.lang;lang=s.lang;}
  if(s.outputCount)outputCount.value=s.outputCount; if(s.folder)folderName.value=s.folder;
  if(s.delayMin){delayMin.value=s.delayMin;setDelayMin.value=s.delayMin;}
  if(s.delayMax){delayMax.value=s.delayMax;setDelayMax.value=s.delayMax;}
  if(s.prompts)promptInput.value=s.prompts;
  if(s.history)history=s.history; if(s.presets)presets=s.presets;
  if(s.theme)applyTheme(s.theme);
  currentMode=(s.mode==='text-to-video')?'text':'image';
  updateModeUI();updatePromptCount();renderPresets();renderHistory();
  applyI18n();await checkGrokTab();
  try{
    const activeTabs=await chrome.tabs.query({active:true,currentWindow:true});
    const activeUrl=(activeTabs[0]&&activeTabs[0].url)||'';
    if(!activeUrl.includes('grok.com')){document.getElementById('grokModal').style.display='flex';}
  }catch{}
}

// ═══════════════════════════════════════
// 4. i18n
// ═══════════════════════════════════════
function t(key,vars={}){
  let s=(I18N[lang]&&I18N[lang][key])||I18N.ko[key]||key;
  Object.entries(vars).forEach(([k,v])=>{s=s.replace(`{${k}}`,v);});
  return s;
}
function applyI18n(){
  document.querySelectorAll('[data-i]').forEach(el=>{
    const key=el.getAttribute('data-i');
    el.textContent=t(key);
  });
  document.querySelectorAll('[data-i-placeholder]').forEach(el=>{
    el.placeholder=t(el.getAttribute('data-i-placeholder'));
  });
  document.querySelectorAll('[data-i-html]').forEach(el=>{
    el.innerHTML=t(el.getAttribute('data-i-html'));
  });
  // Update dynamic counts
  updatePromptCount();
  imgCount.textContent=t('imgCount',{n:uploadedImages.length});
  qCount.textContent=t('queueCount',{n:queue.length});
}

// Language change triggers i18n
setLang.addEventListener('change',()=>{lang=setLang.value;applyI18n();});

// ═══════════════════════════════════════
// 13. THEME
// ═══════════════════════════════════════
function applyTheme(th){document.documentElement.setAttribute('data-theme',th);themeBtn.textContent=th==='dark'?'☀️':'🌙';chrome.storage.local.set({theme:th});}
themeBtn.addEventListener('click',()=>{applyTheme(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark');});

// ═══════════════════════════════════════
// 14. KEYBOARD SHORTCUTS
// ═══════════════════════════════════════
document.addEventListener('keydown',e=>{
  if(e.ctrlKey&&e.key==='Enter'){e.preventDefault();if(!isRunning)runBtn.click();}
  if(e.key==='Escape'){e.preventDefault();if(isRunning)stopBtn.click();}
  if(e.ctrlKey&&e.key==='p'){e.preventDefault();if(isRunning)pauseBtn.click();}
});

// ═══════════════════════════════════════
// TABS
// ═══════════════════════════════════════
document.querySelectorAll('.tab').forEach(tab=>{tab.addEventListener('click',()=>{
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.tc').forEach(c=>c.classList.remove('active'));
  tab.classList.add('active');$(`tab-${tab.dataset.tab}`).classList.add('active');
});});

// MODE SELECTOR
document.querySelectorAll('.mbtn').forEach(b=>{b.addEventListener('click',()=>{currentMode=b.dataset.mode;updateModeUI();});});
function updateModeUI(){
  document.querySelectorAll('.mbtn').forEach(b=>b.classList.toggle('active',b.dataset.mode===currentMode));
  $('imgSection').style.display=currentMode==='image'?'block':'none';
  $('textSection').style.display=currentMode==='text'?'block':'none';
}

// CONNECTION
async function checkGrokTab(){try{const tabs=await chrome.tabs.query({url:'https://grok.com/*'});if(tabs.length>0){tabId=tabs[0].id;sDot.className='sd on';sTxt.textContent=t('statusConnect');}else{tabId=null;sDot.className='sd';sTxt.textContent=t('statusWait');}}catch{sDot.className='sd err';sTxt.textContent=t('statusError');}}
setInterval(checkGrokTab,5000);

// PROMPT
function parsePrompts(text){return text.split(/\n\s*\n/).map(b=>b.trim()).filter(b=>b.length>0);}
function updatePromptCount(){promptCount.textContent=t('promptCount',{n:parsePrompts(promptInput.value).length});chrome.storage.local.set({prompts:promptInput.value});}
promptInput.addEventListener('input',updatePromptCount);

// ═══════════════════════════════════════
// 8. PRESETS
// ═══════════════════════════════════════
presetSaveBtn.addEventListener('click',()=>{
  const name=presetName.value.trim();if(!name)return;
  presets=presets.filter(p=>p.name!==name);
  presets.push({name,text:promptInput.value,images:uploadedImages.map(i=>({name:i.name,prompt:i.prompt}))});
  chrome.storage.local.set({presets});renderPresets();presetName.value='';
  sTxt.textContent=t('statusPresetSaved');setTimeout(checkGrokTab,2000);
});
function renderPresets(){
  presetList.innerHTML='';
  presets.forEach(p=>{
    const tag=document.createElement('div');tag.className='preset-tag';
    tag.innerHTML=`<span class="pt-load">${esc(p.name)}</span><span class="pt-x" data-name="${esc(p.name)}">✕</span>`;
    tag.querySelector('.pt-load').addEventListener('click',()=>{
      promptInput.value=p.text||'';updatePromptCount();
      sTxt.textContent=t('statusPresetLoaded');setTimeout(checkGrokTab,2000);
    });
    tag.querySelector('.pt-x').addEventListener('click',e=>{
      e.stopPropagation();
      presets=presets.filter(x=>x.name!==p.name);
      chrome.storage.local.set({presets});renderPresets();
      sTxt.textContent=t('statusPresetDeleted');setTimeout(checkGrokTab,2000);
    });
    presetList.appendChild(tag);
  });
}

// ═══════════════════════════════════════
// 9. CSV/TXT IMPORT
// ═══════════════════════════════════════
csvImportBtn.addEventListener('click',()=>csvFileInput.click());
csvFileInput.addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file)return;
  const text=await file.text();
  let prompts=[];
  if(file.name.endsWith('.csv')){
    // Each line = one prompt, skip empty
    prompts=text.split('\n').map(l=>l.replace(/^"|"$/g,'').trim()).filter(l=>l);
  }else{
    // TXT: blank-line separated
    prompts=text.split(/\n\s*\n/).map(b=>b.trim()).filter(b=>b);
  }
  if(prompts.length>0){
    promptInput.value=(promptInput.value?promptInput.value+'\n\n':'')+prompts.join('\n\n');
    updatePromptCount();
    sTxt.textContent=t('statusFileLoaded',{n:prompts.length});setTimeout(checkGrokTab,2000);
  }
  csvFileInput.value='';
});

// IMAGE UPLOAD
let _uploadBusy=false;
uploadZone.addEventListener('click',(e)=>{
  if(e.target===fileInput)return; // prevent loop
  e.stopPropagation();
  if(!_uploadBusy)fileInput.click();
});
fileInput.addEventListener('click',e=>e.stopPropagation());
fileInput.addEventListener('change',e=>{
  if(_uploadBusy)return;_uploadBusy=true;
  handleFiles(e.target.files);
  fileInput.value='';
  setTimeout(()=>{_uploadBusy=false;},500);
});
uploadZone.addEventListener('dragover',e=>{e.preventDefault();uploadZone.classList.add('dragover');});
uploadZone.addEventListener('dragleave',()=>uploadZone.classList.remove('dragover'));
uploadZone.addEventListener('drop',e=>{e.preventDefault();uploadZone.classList.remove('dragover');handleFiles(e.dataTransfer.files);});

function handleFiles(files){
  const fileArr=Array.from(files);
  for(const f of fileArr){
    if(!f.type.startsWith('image/'))continue;
    if(f.size>10*1024*1024){sTxt.textContent=t('statusSizeOver',{name:f.name});continue;}
    // Dedup check: same name + same size = skip
    const isDup=uploadedImages.some(img=>img.name===f.name&&img.size===f.size);
    if(isDup){log('⚠️ 중복 이미지 건너뜀: '+f.name);continue;}
    const r=new FileReader();
    r.onload=ev=>{
      // Double-check dedup (async safety)
      if(uploadedImages.some(img=>img.name===f.name&&img.size===f.size))return;
      uploadedImages.push({id:Date.now()+'_'+Math.random().toString(36).slice(2,6),name:f.name,size:f.size,dataUrl:ev.target.result,prompt:''});
      renderImages();
    };
    r.readAsDataURL(f);
  }
}
function renderImages(){
  imgList.innerHTML='';
  uploadedImages.forEach((img,i)=>{
    const d=document.createElement('div');d.className='ii';d.draggable=true;d.dataset.idx=i;
    d.innerHTML=`<span class="ii-grip">⠿</span><img src="${img.dataUrl}"><div class="ii-b"><div class="ii-n">${esc(img.name)}</div></div><button class="ii-rm" data-id="${img.id}">✕</button>`;
    d.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',i);d.style.opacity='0.4';});
    d.addEventListener('dragend',()=>{d.style.opacity='';imgList.querySelectorAll('.ii').forEach(x=>x.style.borderTop='');});
    d.addEventListener('dragover',e=>{e.preventDefault();d.style.borderTop='2px solid var(--g5)';});
    d.addEventListener('dragleave',()=>{d.style.borderTop='';});
    d.addEventListener('drop',e=>{e.preventDefault();d.style.borderTop='';const from=parseInt(e.dataTransfer.getData('text/plain'));const to=parseInt(d.dataset.idx);if(from===to)return;const item=uploadedImages.splice(from,1)[0];uploadedImages.splice(to,0,item);renderImages();});
    imgList.appendChild(d);
  });
  imgList.querySelectorAll('.ii-rm').forEach(b=>b.addEventListener('click',e=>{
    uploadedImages=uploadedImages.filter(x=>x.id!==e.target.dataset.id);
    renderImages();
  }));
  imgCount.textContent=t('imgCount',{n:uploadedImages.length});
  renderPreview();
}

// 이미지 모드 프롬프트 입력 감지
const imgPromptInput=$('imgPromptInput');
const imgPromptCount=$('imgPromptCount');
if(imgPromptInput){
  imgPromptInput.addEventListener('input',()=>{
    const blocks=parsePrompts(imgPromptInput.value);
    imgPromptCount.textContent=t('promptCount',{n:blocks.length});
    renderPreview();
  });
}

// ═══════════════════════════════════════
// PREVIEW: 이미지 ↔ 프롬프트 매칭 미리보기
// ═══════════════════════════════════════
function renderPreview(){
  const previewSection=$('previewSection');
  const previewList=$('previewList');
  if(!previewSection||!previewList) return;

  if(uploadedImages.length===0){
    previewSection.style.display='none';
    return;
  }
  previewSection.style.display='block';
  previewList.innerHTML='';

  const prompts = imgPromptInput ? parsePrompts(imgPromptInput.value) : [];
  const defaultDur = ($('setDuration')?.value || '6').replace('-concat','');

  uploadedImages.forEach((img,idx)=>{
    const prompt = prompts[idx] || '';
    const charCount = prompt.length;
    const card = document.createElement('div');
    card.className='pv-card';
    card.innerHTML=`
      <select class="pv-dur" data-idx="${idx}">
        <option value="6" ${defaultDur==='6'?'selected':''}>6초</option>
        <option value="10" ${defaultDur==='10'?'selected':''}>10초</option>
      </select>
      <div class="pv-info">
        <div class="pv-num">${idx+1}. ${esc(prompt||'(프롬프트 없음)')}</div>
        <div class="pv-meta">${charCount} characters - ${img.duration||defaultDur}s</div>
      </div>
      <img class="pv-thumb" src="${img.dataUrl}">
    `;
    card.querySelector('.pv-dur').addEventListener('change',e=>{
      uploadedImages[idx].duration=e.target.value;
      const meta=card.querySelector('.pv-meta');
      if(meta) meta.textContent=`${charCount} characters - ${e.target.value}s`;
    });
    previewList.appendChild(card);
  });
}

// ═══════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════
saveBtn.addEventListener('click',()=>{
  chrome.storage.local.set({mode:setMode.value,ratio:setRatio.value,duration:setDuration.value,retry:parseInt(setRetry.value),quality:setQuality.value,lang:setLang.value,outputCount:parseInt(outputCount.value),folder:folderName.value,delayMin:parseInt(setDelayMin.value),delayMax:parseInt(setDelayMax.value)});
  delayMin.value=setDelayMin.value;delayMax.value=setDelayMax.value;lang=setLang.value;applyI18n();
  sTxt.textContent=t('statusSaved');setTimeout(checkGrokTab,2000);
});
resetBtn.addEventListener('click',()=>{
  setMode.value=DEFAULTS.mode;setRatio.value=DEFAULTS.ratio;setDuration.value=DEFAULTS.duration;setRetry.value=DEFAULTS.retry;setQuality.value=DEFAULTS.quality;setLang.value=DEFAULTS.lang;
  outputCount.value=DEFAULTS.outputCount;folderName.value=DEFAULTS.folder;setDelayMin.value=DEFAULTS.delayMin;setDelayMax.value=DEFAULTS.delayMax;delayMin.value=DEFAULTS.delayMin;delayMax.value=DEFAULTS.delayMax;
  sTxt.textContent=t('statusDefaultReset');setTimeout(checkGrokTab,2000);
});

// ═══════════════════════════════════════
// 15. EXPORT / IMPORT
// ═══════════════════════════════════════
exportBtn.addEventListener('click',async()=>{
  const data=await chrome.storage.local.get(null);
  const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;
  a.download=`utogrok-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url);
  sTxt.textContent=t('statusExported');setTimeout(checkGrokTab,2000);
});
importBtn.addEventListener('click',()=>importFile.click());
importFile.addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file)return;
  try{const data=JSON.parse(await file.text());await chrome.storage.local.set(data);sTxt.textContent=t('statusImported');setTimeout(()=>location.reload(),1000);}
  catch{sTxt.textContent=t('statusBadJson');}importFile.value='';
});

// ═══════════════════════════════════════
// 11. HISTORY
// ═══════════════════════════════════════
function renderHistory(){
  if(history.length===0){histBody.innerHTML=`<div class="hist-empty">${t('histEmpty')}</div>`;return;}
  let html=`<table class="hist-tbl"><thead><tr><th>${t('histDate')}</th><th>${t('histType')}</th><th>${t('histPrompt')}</th><th>${t('histResult')}</th></tr></thead><tbody>`;
  history.slice().reverse().slice(0,100).forEach(h=>{
    const d=new Date(h.date);const ds=`${d.getMonth()+1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
    html+=`<tr><td>${ds}</td><td>${h.type==='image'?'🖼️':'📝'}</td><td title="${esc(h.prompt||'')}">${esc((h.prompt||'').substring(0,30))}</td><td class="${h.success?'ok':'fail'}">${h.success?t('histSuccess'):t('histFail')}${h.error?` — ${esc(h.error.substring(0,30))}`:''}</td></tr>`;
  });
  html+='</tbody></table>';histBody.innerHTML=html;
}
histClearBtn.addEventListener('click',()=>{history=[];chrome.storage.local.set({history:[]});renderHistory();});

// ═══════════════════════════════════════
// RUN / STOP / PAUSE / CLEAR / BUG
// ═══════════════════════════════════════
document.getElementById('imgSortBtn').addEventListener('click',()=>{uploadedImages.sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}));renderImages();});
document.getElementById('refreshBtn').addEventListener('click',async()=>{try{const tabs=await chrome.tabs.query({url:'https://grok.com/*'});if(tabs.length>0){chrome.tabs.reload(tabs[0].id);sTxt.textContent='🔃 Grok 페이지 새로고침 중...';setTimeout(checkGrokTab,3000);}else{sTxt.textContent='⚠️ Grok 탭이 없습니다';}}catch{sTxt.textContent='⚠️ 새로고침 실패';}});
document.getElementById('helpBtn').addEventListener('click',()=>{chrome.tabs.create({url:atob('aHR0cHM6Ly9tb29uZDkxLmdpdGh1Yi5pby91dG8tZ3Jvay8=')});});
bugBtn.addEventListener('click',()=>document.getElementById('bugModal').style.display='flex');
document.getElementById('bugModalX').addEventListener('click',()=>document.getElementById('bugModal').style.display='none');
document.getElementById('bugModalOk').addEventListener('click',()=>document.getElementById('bugModal').style.display='none');
document.getElementById('bugModalCafe').addEventListener('click',()=>{chrome.tabs.create({url:atob('aHR0cHM6Ly9jYWZlLm5hdmVyLmNvbS9yZWQxM2JjZy82NTg=')});document.getElementById('bugModal').style.display='none';});
document.getElementById('bugModal').addEventListener('click',(e)=>{if(e.target.id==='bugModal')e.target.style.display='none';});
document.getElementById('grokModalX').addEventListener('click',()=>document.getElementById('grokModal').style.display='none');
document.getElementById('grokModalGo').addEventListener('click',()=>{chrome.tabs.create({url:'https://grok.com/imagine'});document.getElementById('grokModal').style.display='none';});
document.getElementById('grokModal').addEventListener('click',(e)=>{if(e.target.id==='grokModal')e.target.style.display='none';});
clearBtn.addEventListener('click',()=>{promptInput.value='';if(imgPromptInput)imgPromptInput.value='';uploadedImages=[];queue=[];currentIndex=0;renderImages();updatePromptCount();if(imgPromptCount)imgPromptCount.textContent=t('promptCount',{n:0});qBody.innerHTML='';qCount.textContent=t('queueCount',{n:0});progSec.style.display='none';etaText.textContent='';stepBadge.innerHTML='';qStatusTxt.textContent='';sTxt.textContent=t('statusReset');});

// 16. PAUSE/RESUME
pauseBtn.addEventListener('click',()=>{
  if(!isRunning)return;isPaused=!isPaused;
  if(isPaused){pauseBtn.textContent=t('btnResume');qStatusTxt.textContent=t('statusPaused');sDot.className='sd on';}
  else{pauseBtn.textContent=t('btnPause');qStatusTxt.textContent=t('statusResumed');sDot.className='sd run';if(pauseResolve){pauseResolve();pauseResolve=null;}}
});
function waitIfPaused(){if(!isPaused)return Promise.resolve();return new Promise(r=>{pauseResolve=r;});}

// RUN
runBtn.addEventListener('click',async()=>{
  await checkGrokTab();if(!tabId){sDot.className='sd err';sTxt.textContent=t('statusNoTab');return;}
  const oc=parseInt(outputCount.value)||1;queue=[];

  if(currentMode==='image'&&uploadedImages.length>0){
    const prompts = imgPromptInput ? parsePrompts(imgPromptInput.value) : [];

    uploadedImages.forEach((img, idx)=>{
      const matchedPrompt = prompts[idx] || '';
      const itemDuration = img.duration || ($('setDuration')?.value || '6');

      for(let i=0;i<oc;i++){
        queue.push({
          type:'image',
          prompt: matchedPrompt,
          imageDataUrl: img.dataUrl,
          imageName: img.name,
          duration: itemDuration,
          label: img.name,
          thumbUrl: img.dataUrl
        });
      }
    });
  }else{
    const blocks=parsePrompts(promptInput.value);if(blocks.length===0){sTxt.textContent=t('statusNoPrompt');return;}
    blocks.forEach(b=>{for(let i=0;i<oc;i++)queue.push({type:'text',prompt:b,label:b.length>50?b.substring(0,50)+'...':b});});
  }
  if(queue.length===0){sTxt.textContent=t('statusNoItem');return;}
  isRunning=true;isPaused=false;currentIndex=0;genTimes=[];
  updateRunUI();renderQueueItems();processNext();
});

// STOP
stopBtn.addEventListener('click',()=>{
  isRunning=false;isPaused=false;if(pauseResolve){pauseResolve();pauseResolve=null;}
  sDot.className='sd on';qStatusTxt.textContent=t('statusStopped');etaText.textContent='';stepBadge.innerHTML='';
  updateRunUI();sendToContent({action:'STOP'}).catch(()=>{});
});

// ═══════════════════════════════════════
// PROCESS QUEUE
// ═══════════════════════════════════════
async function processNext(){
  if(!isRunning||currentIndex>=queue.length){
    if(currentIndex>=queue.length){
      isRunning=false;isPaused=false;sDot.className='sd on';
      qStatusTxt.textContent=t('statusDone',{n:queue.length});etaText.textContent='';stepBadge.innerHTML='';
      updateRunUI();saveHistory();
      // 6. NOTIFICATION
      try{chrome.runtime.sendMessage({type:'NOTIFY',title:t('notifTitle'),body:t('notifBody',{n:queue.length})});}catch{}
    }
    return;
  }
  await waitIfPaused();if(!isRunning)return;

  const item=queue[currentIndex];const maxRetry=parseInt(setRetry.value)||5;
  let success=false,errorMsg='';const genStart=Date.now();

  sDot.className='sd run';qStatusTxt.textContent=t('statusGen',{cur:currentIndex+1,total:queue.length});
  updateProgress();updateETA();setQueueItemState(currentIndex,'active');

  for(let attempt=1;attempt<=maxRetry;attempt++){
    if(!isRunning)return;await waitIfPaused();
    try{
      const retryLabel=attempt>1?` ${t('statusRetry',{a:attempt,max:maxRetry})}`:'';
      qStatusTxt.textContent=t('statusGen',{cur:currentIndex+1,total:queue.length})+retryLabel;

      // 12. STEP PROGRESS
      showStep('input');
      const res=await sendToContent({action:'GENERATE',type:item.type,prompt:item.prompt,imageDataUrl:item.imageDataUrl||null,ratio:setRatio.value,duration:item.duration||setDuration.value,quality:setQuality.value,folder:folderName.value});

      if(res?.success){success=true;showStep('done');break;}
      else{
        errorMsg=res?.error||'Unknown error';showStep('error');
        // ★ 전송 버튼/업로드 실패 시 자동 새로고침
        if(attempt<maxRetry&&(errorMsg.includes('전송 버튼')||errorMsg.includes('업로드')||errorMsg.includes('찾을 수 없'))){
          qStatusTxt.textContent='🔃 Grok 페이지 자동 새로고침 중...';
          try{const tabs=await chrome.tabs.query({url:'https://grok.com/*'});if(tabs.length>0){chrome.tabs.reload(tabs[0].id);await sleep(5000);await checkGrokTab();}}catch{}
        }
      }
      if(attempt<maxRetry)await sleep(3000);
    }catch(err){
      errorMsg=err.message||'Connection error';showStep('error');
      // ★ 연결 에러 시 자동 새로고침 후 재시도
      if(attempt<maxRetry&&(errorMsg.includes('Content script not ready')||errorMsg.includes('No grok tab')||errorMsg.includes('전송 버튼'))){
        qStatusTxt.textContent='🔃 Grok 페이지 자동 새로고침 중...';
        try{const tabs=await chrome.tabs.query({url:'https://grok.com/*'});if(tabs.length>0){chrome.tabs.reload(tabs[0].id);await sleep(5000);await checkGrokTab();}}catch{}
      }
      if(attempt<maxRetry)await sleep(3000);
    }
  }

  genTimes.push(Date.now()-genStart);

  // 7. ERROR MSG + 11. HISTORY
  history.push({date:new Date().toISOString(),type:item.type,prompt:item.prompt?.substring(0,100),success,error:errorMsg||null,imageName:item.imageName||null});

  setQueueItemState(currentIndex,success?'done':'error',errorMsg);
  currentIndex++;updateProgress();updateETA();

  if(isRunning&&currentIndex<queue.length){
    await waitIfPaused();
    const mn=parseInt(delayMin.value)||5,mx=parseInt(delayMax.value)||10;
    const delay=(Math.floor(Math.random()*(mx-mn+1))+mn)*1000;
    qStatusTxt.textContent=t('statusWaiting',{sec:Math.round(delay/1000),cur:currentIndex+1,total:queue.length});
    stepBadge.innerHTML='';
    // ★ 다음 작업 전 Grok 탭 새로고침 (깨끗한 입력 화면)
    try{
      const tabs=await chrome.tabs.query({url:'https://grok.com/*'});
      if(tabs.length>0){
        chrome.tabs.update(tabs[0].id,{url:'https://grok.com/imagine'});
        await sleep(6000); // 페이지 완전 로드 대기
        await checkGrokTab();
      }
    }catch{}
    await sleep(delay);processNext();
  }else if(currentIndex>=queue.length){
    isRunning=false;isPaused=false;sDot.className='sd on';
    // ★ 완료 요약 (성공/실패/업스케일 수)
    const total=queue.length;
    const successCount=queue.filter((_,i)=>{const s=$(`qs-${i}`);return s&&s.textContent==='✅';}).length;
    const failCount=total-successCount;
    const quality=setQuality.value||'480p';
    const upscaleCount=(quality==='480p-upscale'||quality==='720p')?successCount:0;
    let summary=`✅ 완료! 성공 ${successCount}개`;
    if(failCount>0)summary+=` / ❌ 실패 ${failCount}개`;
    if(upscaleCount>0)summary+=` / 🔍 업스케일 ${upscaleCount}개`;
    qStatusTxt.textContent=summary;
    etaText.textContent='';stepBadge.innerHTML='';
    updateRunUI();saveHistory();renderHistory();
    // ★ 실패 건 재실행 버튼
    if(failCount>0){showRetryFailedBtn();}
    try{chrome.runtime.sendMessage({type:'NOTIFY',title:t('notifTitle'),body:summary});}catch{}
  }
}

// 12. STEP BADGE
function showStep(step){
  const map={input:'step-input',send:'step-send',generate:'step-gen',download:'step-dl',done:'step-send',error:'step-input'};
  const cls=map[step]||'step-input';
  const label=t(`step${step.charAt(0).toUpperCase()+step.slice(1)}`)||step;
  stepBadge.innerHTML=`<span class="step-badge ${cls}">${label}</span>`;
}

// 17. ETA
function updateETA(){
  if(genTimes.length===0||currentIndex>=queue.length){etaText.textContent='';return;}
  const avg=genTimes.reduce((a,b)=>a+b,0)/genTimes.length;
  const avgDelay=((parseInt(delayMin.value)||45)+(parseInt(delayMax.value)||60))/2*1000;
  const rem=queue.length-currentIndex;const etaMs=rem*(avg+avgDelay);
  const m=Math.floor(etaMs/60000),s=Math.floor((etaMs%60000)/1000);
  const timeStr=m>0?`${m}분 ${s}초`:`${s}초`;
  etaText.textContent=t('etaRemain',{time:timeStr});
}

function saveHistory(){if(history.length>500)history=history.slice(-500);chrome.storage.local.set({history});}

// COMMUNICATION
function sendToContent(msg){return new Promise((resolve,reject)=>{if(!tabId){reject(new Error('No grok tab'));return;}try{chrome.tabs.sendMessage(tabId,msg,res=>{if(chrome.runtime.lastError){const errMsg=chrome.runtime.lastError.message||'';if(errMsg.includes('Receiving end does not exist')||errMsg.includes('Could not establish connection')){console.warn('[UtoGrok] content script 미연결 — 페이지 새로고침 필요');reject(new Error('Content script not ready'));}else{reject(chrome.runtime.lastError);}}else{resolve(res);}});}catch(e){reject(e);}});}

// ═══════════════════════════════════════
// UI HELPERS
// ═══════════════════════════════════════
function updateRunUI(){
  promptInput.disabled=isRunning;runBtn.style.display=isRunning?'none':'flex';
  stopBtn.style.display=isRunning?'flex':'none';pauseBtn.style.display=isRunning?'flex':'none';
  if(!isRunning){pauseBtn.textContent=t('btnPause');}
  // Show/hide queue status area
  progSec.style.display=(isRunning||currentIndex>0)?'block':'none';
}
function updateProgress(){const total=queue.length,d=currentIndex,p=total>0?Math.round((d/total)*100):0;progFill.style.width=p+'%';progDone.textContent=`${d}/${total}`;progPct.textContent=p+'%';}

// 10. QUEUE MANAGEMENT (drag, delete, rerun)
function renderQueueItems(){
  qBody.innerHTML='';qCount.textContent=t('queueCount',{n:queue.length});
  queue.forEach((item,i)=>{
    const d=document.createElement('div');d.className='qi';d.id=`qi-${i}`;
    d.draggable=!isRunning;d.dataset.idx=i;
    const thumb=item.thumbUrl?`<img class="qi-thumb" src="${item.thumbUrl}">`:'';

    // 이미지 모드: 파일명 + 프롬프트 2줄 표시
    let labelHtml = '';
    if(item.type==='image'){
      const nameText = esc(item.imageName||'image');
      const promptText = item.prompt ? esc(item.prompt.length>40 ? item.prompt.substring(0,40)+'...' : item.prompt) : '<span style="color:var(--t4);font-style:italic">프롬프트 없음 (자동)</span>';
      labelHtml = `<div class="qi-t2"><div class="qi-name">${nameText}</div><div class="qi-prompt">${promptText}</div></div>`;
    } else {
      labelHtml = `<span class="qi-t">${esc(item.label)}</span>`;
    }

    d.innerHTML=`<span class="qi-n">${String(i+1).padStart(2,'0')}</span>${thumb}${labelHtml}<span class="qi-s" id="qs-${i}">⏳</span>
    <div class="qi-acts"><button class="qi-act rerun" data-idx="${i}" title="${t('queueRerun')}">↻</button><button class="qi-act del" data-idx="${i}" title="${t('queueDelete')}">✕</button></div>
    <div class="qi-err" id="qe-${i}"></div>`;
    // Drag events
    d.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',i);d.classList.add('dragging');});
    d.addEventListener('dragend',()=>d.classList.remove('dragging'));
    d.addEventListener('dragover',e=>{e.preventDefault();d.style.borderTop='2px solid var(--g5)';});
    d.addEventListener('dragleave',()=>{d.style.borderTop='';});
    d.addEventListener('drop',e=>{
      e.preventDefault();d.style.borderTop='';
      const from=parseInt(e.dataTransfer.getData('text/plain'));const to=parseInt(d.dataset.idx);
      if(from===to||isRunning)return;
      const [moved]=queue.splice(from,1);queue.splice(to,0,moved);renderQueueItems();
    });
    qBody.appendChild(d);
  });
  // Bind rerun/delete
  qBody.querySelectorAll('.qi-act.del').forEach(b=>b.addEventListener('click',e=>{
    if(isRunning)return;const idx=parseInt(e.target.dataset.idx);queue.splice(idx,1);renderQueueItems();
  }));
  qBody.querySelectorAll('.qi-act.rerun').forEach(b=>b.addEventListener('click',e=>{
    if(isRunning)return;const idx=parseInt(e.target.dataset.idx);
    const item={...queue[idx]};queue.push(item);renderQueueItems();
  }));
}

function setQueueItemState(i,state,errorMsg=''){
  const el=$(`qi-${i}`),s=$(`qs-${i}`),err=$(`qe-${i}`);
  if(!el||!s)return;
  el.className=`qi ${state}`;el.draggable=false;
  s.textContent=state==='active'?'🔄':state==='done'?'✅':'❌';
  // 7. Show error message
  if(state==='error'&&errorMsg&&err){err.textContent=errorMsg;err.style.display='block';}
  el.scrollIntoView({behavior:'smooth',block:'nearest'});
}

// ★ Web Worker 기반 타이머 (창 최소화해도 안 느려짐)
const workerBlob=new Blob([`self.onmessage=function(e){setTimeout(function(){self.postMessage('done')},e.data)}`],{type:'application/javascript'});
const workerUrl=URL.createObjectURL(workerBlob);

function sleep(ms){
  return new Promise(resolve=>{
    try{
      const w=new Worker(workerUrl);
      w.onmessage=()=>{w.terminate();resolve();};
      w.postMessage(ms);
    }catch{
      setTimeout(resolve,ms);
    }
  });
}

// ★ 실패 건 재실행 버튼
function showRetryFailedBtn(){
  const existing=document.getElementById('retryFailedBtn');
  if(existing)existing.remove();
  const failedItems=queue.filter((_,i)=>{const s=$(`qs-${i}`);return s&&s.textContent==='❌';});
  if(failedItems.length===0)return;
  const btn=document.createElement('button');
  btn.id='retryFailedBtn';
  btn.textContent=`🔄 실패 ${failedItems.length}건 재실행`;
  btn.style.cssText='width:100%;padding:10px;border:none;border-radius:8px;background:var(--dnbg);color:var(--dn);font-size:13px;font-weight:600;cursor:pointer;margin:8px 0;font-family:inherit';
  btn.addEventListener('click',()=>{
    btn.remove();
    const retryItems=failedItems.map(item=>({...item}));
    queue.length=0;queue.push(...retryItems);
    currentIndex=0;genTimes.length=0;
    renderQueueItems();updateProgress();
    isRunning=true;updateRunUI();processNext();
  });
  qBody.parentElement.insertBefore(btn,qBody);
}
function esc(s){return(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

chrome.runtime.onMessage.addListener((msg,sender)=>{
  if(msg.type==='TAB_READY'){tabId=sender.tab?.id;sDot.className='sd on';sTxt.textContent=t('statusConnect');}
  // 12. Step updates from content script
  if(msg.type==='STEP_UPDATE')showStep(msg.step);
});

// ═══════════════════════════════════════════════
// ★ 신청 승인제 인증 시스템
// ═══════════════════════════════════════════════
async function checkAuth(){
  const emailEl = $('authEmail');
  let email = '';

  // Chrome 이메일 감지
  try{
    const info = await chrome.identity.getProfileUserInfo({accountStatus:'ANY'});
    email = info.email || '';
  }catch{}

  if(!email){
    showAuthScreen('form');
    emailEl.textContent = '⚠️ Chrome에 로그인해주세요';
    emailEl.dataset.email = '';
    return false;
  }
  emailEl.textContent = email;
  emailEl.dataset.email = email;

  // 이미 승인된 상태인지 로컬 캐시 확인
  const stored = await chrome.storage.local.get(['utoApproved','utoEmail']);
  if(stored.utoApproved && stored.utoEmail === email){
    try{
      const res = await callAPI({action:'check', email});
      if(res.status === 'approved'){showMainContent();return true;}
      if(res.status === 'blocked'||res.status === 'expired'){await chrome.storage.local.remove(['utoApproved','utoEmail']);showAuthScreen('expired');return false;}
    }catch{
      showMainContent();return true;
    }
  }

  // 서버에서 상태 확인
  try{
    const res = await callAPI({action:'check', email});
    if(res.status === 'approved'){
      await chrome.storage.local.set({utoApproved:true, utoEmail:email});
      showMainContent();return true;
    }
    if(res.status === 'pending'){showAuthScreen('pending');return false;}
    if(res.status === 'expired'){showAuthScreen('expired');return false;}
  }catch{}

  // 미등록 → 신청 폼 표시
  showAuthScreen('form');
  return false;
}

function showMainContent(){
  $('authScreen').style.display='none';
  $('mainContent').style.display='flex';
  checkForUpdate();
}

// ★ 업데이트 확인
async function checkForUpdate(){
  try{
    const res=await callAPI({action:'version'});
    if(res.latestVersion){
      const current='3.0.0';
      if(res.latestVersion&&res.latestVersion!==current&&res.latestVersion.localeCompare(current,undefined,{numeric:true})>0){
        const bar=document.createElement('div');
        bar.style.cssText='background:#F59E0B;color:#fff;padding:8px 14px;font-size:11px;display:flex;align-items:center;gap:8px;font-family:inherit';
        bar.innerHTML='<span style="flex:1;cursor:pointer" id="updateLink">🔔 새 버전 v'+res.latestVersion+' 사용 가능! (현재 v'+current+')</span><span id="updateGo" style="font-size:12px;font-weight:700;cursor:pointer">업데이트 →</span><span id="updateClose" style="font-size:14px;cursor:pointer;margin-left:4px;opacity:0.8">✕</span>';
        $('mainContent').insertBefore(bar,$('mainContent').firstChild);
        $('updateLink').addEventListener('click',()=>{chrome.tabs.create({url:res.downloadUrl});});
        $('updateGo').addEventListener('click',()=>{chrome.tabs.create({url:res.downloadUrl});});
        $('updateClose').addEventListener('click',(e)=>{e.stopPropagation();bar.remove();});
      }
    }
  }catch{}
  // ★ 만료 임박 경고
  checkExpiryWarning();
}

// ★ 만료 임박 경고 (D-7)
async function checkExpiryWarning(){
  try{
    const email=($('authEmail')?.dataset?.email||'').trim();
    if(!email)return;
    const res=await callAPI({action:'check',email});
    if(res.status==='approved'&&res.expiryDate){
      const expiry=new Date(res.expiryDate);
      const now=new Date();
      const daysLeft=Math.ceil((expiry-now)/(1000*60*60*24));
      if(daysLeft<=7&&daysLeft>0){
        const bar=document.createElement('div');
        bar.style.cssText='background:#92400E;color:#FDE68A;padding:8px 14px;font-size:11px;display:flex;align-items:center;justify-content:space-between;font-family:inherit';
        bar.innerHTML='<span>⚠️ 이용 기간 만료 D-'+daysLeft+' ('+expiry.toLocaleDateString('ko-KR')+'까지)</span><span id="expiryClose" style="cursor:pointer;opacity:0.8">✕</span>';
        const firstChild=$('mainContent').firstChild;
        if(firstChild)$('mainContent').insertBefore(bar,firstChild.nextSibling||firstChild);
        else $('mainContent').appendChild(bar);
        $('expiryClose').addEventListener('click',()=>{bar.remove();});
      }
    }
  }catch{}
}

function showAuthScreen(mode){
  $('authScreen').style.display='flex';
  $('mainContent').style.display='none';
  $('authFormSection').style.display = mode==='form' ? 'block' : 'none';
  $('authPendingSection').style.display = mode==='pending' ? 'block' : 'none';
  $('authExpiredSection').style.display = mode==='expired' ? 'block' : 'none';
  if(mode==='pending') $('authSubtitle').textContent='승인 대기 중입니다';
  else if(mode==='expired') $('authSubtitle').textContent='이용 기간이 만료되었습니다';
  else $('authSubtitle').textContent='사용 신청이 필요합니다';
}

async function callAPI(data){
  if(LICENSE_API_URL === 'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE'){
    return {status:'approved', message:'개발 모드'};
  }
  try{
    const params = encodeURIComponent(JSON.stringify(data));
    const url = LICENSE_API_URL + '?data=' + params;
    const res = await fetch(url, {redirect:'follow'});
    const text = await res.text();
    console.log('[UtoGrok] 서버 응답:', text.substring(0,300));
    try{ return JSON.parse(text); }catch{ 
      return {status:'error', error:'서버 응답 오류'}; 
    }
  }catch(err){
    console.error('[UtoGrok] API 에러:', err);
    return {status:'error', error:'서버 연결 실패'};
  }
}

// 신청하기 버튼
$('authApplyBtn').addEventListener('click', async()=>{
  const email = ($('authEmail').dataset.email || '').trim();
  const name = $('authName').value.trim();
  const nickname = $('authNickname').value.trim();
  const course = $('authCourse').value.trim();
  const msg = $('authMsg');

  if(!email){msg.style.color='var(--dn)';msg.textContent='Chrome에 구글 계정으로 로그인해주세요.';return;}
  if(!name){msg.style.color='var(--dn)';msg.textContent='성함을 입력해주세요.';return;}
  if(!nickname){msg.style.color='var(--dn)';msg.textContent='닉네임을 입력해주세요.';return;}
  if(!course){msg.style.color='var(--dn)';msg.textContent='강의명을 입력해주세요.';return;}

  msg.style.color='var(--g4)';msg.textContent='신청 중...';
  $('authApplyBtn').disabled=true;

  try{
    const res = await callAPI({action:'apply', email, name, nickname, course});
    if(res.success){
      msg.style.color='var(--g4)';msg.textContent='✅ ' + (res.message||'신청 완료!');
      await chrome.storage.local.set({utoEmail:email});
      setTimeout(()=>showAuthScreen('pending'), 1500);
    }else{
      msg.style.color='var(--dn)';msg.textContent='❌ ' + (res.error||'신청 실패');
    }
  }catch{
    msg.style.color='var(--dn)';msg.textContent='❌ 서버 연결 실패. 잠시 후 다시 시도하세요.';
  }
  $('authApplyBtn').disabled=false;
});

// 승인 상태 확인 버튼
$('authCheckBtn').addEventListener('click', async()=>{
  const email = ($('authEmail').dataset.email || '').trim();
  const msg = $('authMsg');

  msg.style.color='var(--g4)';msg.textContent='확인 중...';

  try{
    const res = await callAPI({action:'check', email});
    if(res.status === 'approved'){
      msg.style.color='var(--g4)';msg.textContent='✅ 승인 완료!';
      await chrome.storage.local.set({utoApproved:true, utoEmail:email});
      setTimeout(()=>{showMainContent();init();}, 1000);
    }else if(res.status === 'pending'){
      msg.style.color='var(--wn)';msg.textContent='⏳ 아직 승인 대기 중입니다.';
    }else if(res.status === 'blocked'||res.status === 'expired'){
      msg.style.color='var(--dn)';msg.textContent='⏰ 이용 기간이 만료되었습니다.';
      setTimeout(()=>showAuthScreen('expired'), 1500);
    }else{
      msg.style.color='var(--dn)';msg.textContent='❌ ' + (res.error||'상태 확인 실패');
    }
  }catch{
    msg.style.color='var(--dn)';msg.textContent='❌ 서버 연결 실패';
  }
});

// Enter 키
$('authCourse').addEventListener('keydown',(e)=>{if(e.key==='Enter')$('authApplyBtn').click();});

init();
})();