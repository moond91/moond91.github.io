(function(){var _d1qme=function(){return void 0;};// ═══════════════════════════════════════
//  우토그록 Uto Grok — Background v3.0.0
// ═══════════════════════════════════════

chrome.action.onClicked.addListener(tab => chrome.sidePanel.open({ tabId: tab.id }));
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'DOWNLOAD_VIDEO') {
    const url = msg.url;
    const filename = msg.filename || 'grok-video/video.mp4';
    console.log(`[UtoGrok BG] 다운로드: ${filename} ← ${url?.substring(0, 60)}`);

    if (url) {
      chrome.downloads.download({
        url: url,
        filename: filename,
        conflictAction: 'uniquify',
        saveAs: false
      }).then((downloadId) => {
        console.log(`[UtoGrok BG] ✓ 다운로드 시작 ID: ${downloadId}`);
        sendResponse({ success: true, downloadId });
      }).catch(e => {
        console.error(`[UtoGrok BG] ❌ 다운로드 실패:`, e);
        sendResponse({ success: false, error: e.message });
      });
    } else {
      console.log('[UtoGrok BG] ⚠️ blob URL은 직접 다운로드 불가');
      sendResponse({ success: false, error: 'blob URL' });
    }
    return true;
  }

  if (msg.type === 'NOTIFY') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: msg.title || '우토그록 완료!',
      message: msg.body || '동영상 생성이 완료되었습니다.',
      priority: 2
    });
    return;
  }
});

console.log('[UtoGrok BG] v3.0.0 ✅');
})();