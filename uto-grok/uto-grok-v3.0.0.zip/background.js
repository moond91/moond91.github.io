(function(){var _xllqa=function(){return !1;};var _s=[atob('RE9XTkxPQURfVklERU8='),atob('Z3Jvay12aWRlby92aWRlby5tcDQ='),atob('dW5pcXVpZnk='),atob('W1V0b0dyb2sgQkddIOKaoO+4jyBibG9iIFVSTOydgCDsp4HsoJEg64uk7Jq066Gc65OcIOu2iOqwgA=='),atob('YmxvYiBVUkw='),atob('Tk9USUZZ'),atob('YmFzaWM='),atob('aWNvbnMvaWNvbjEyOC5wbmc='),atob('7Jqw7Yag6re466GdIOyZhOujjCE='),atob('64+Z7JiB7IOBIOyDneyEseydtCDsmYTro4zrkJjsl4jsirXri4jri6Qu'),atob('W1V0b0dyb2sgQkddIHYzLjAuMCDinIU=')];// ═══════════════════════════════════════
//  우토그록 Uto Grok — Background v3.0.0
// ═══════════════════════════════════════

chrome.action.onClicked.addListener(tab => chrome.sidePanel.open({ tabId: tab.id }));
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === _s[0]) {
    const url = msg.url;
    const filename = msg.filename || _s[1];
    console.log(`[UtoGrok BG] 다운로드: ${filename} ← ${url?.substring(0, 60)}`);

    if (url) {
      chrome.downloads.download({
        url: url,
        filename: filename,
        conflictAction: _s[2],
        saveAs: false
      }).then((downloadId) => {
        console.log(`[UtoGrok BG] ✓ 다운로드 시작 ID: ${downloadId}`);
        sendResponse({ success: true, downloadId });
      }).catch(e => {
        console.error(`[UtoGrok BG] ❌ 다운로드 실패:`, e);
        sendResponse({ success: false, error: e.message });
      });
    } else {
      console.log(_s[3]);
      sendResponse({ success: false, error: _s[4] });
    }
    return true;
  }

  if (msg.type === _s[5]) {
    chrome.notifications.create({
      type: _s[6],
      iconUrl: _s[7],
      title: msg.title || _s[8],
      message: msg.body || _s[9],
      priority: 2
    });
    return;
  }
});

console.log(_s[10]);
})();