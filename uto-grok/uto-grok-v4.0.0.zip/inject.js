// ═══════════════════════════════════════════════
// 우토그록 — MAIN World 스크립트 (페이지 컨텍스트)
// CSP 우회: manifest.json에서 world:"MAIN"으로 등록
// ═══════════════════════════════════════════════

(function() {
  console.log('[UtoGrok MAIN] 페이지 컨텍스트 로드 ✅');

  // content.js에서 보내는 이벤트 수신
  document.addEventListener('uto-upload', function(e) {
    if (e.detail && e.detail.dataUrl) {
      window.__utoFileData = e.detail.dataUrl;
      console.log('[UtoGrok MAIN] ✓ 파일 데이터 수신 (' + Math.round(e.detail.dataUrl.length/1024) + 'KB)');
    }
  });

  // DOM attribute 감시 (폴백)
  const observer = new MutationObserver(function(mutations) {
    for (const m of mutations) {
      if (m.attributeName === 'data-uto-file') {
        const dataUrl = document.documentElement.getAttribute('data-uto-file');
        if (dataUrl && dataUrl.startsWith('data:')) {
          window.__utoFileData = dataUrl;
          console.log('[UtoGrok MAIN] ✓ 파일 데이터 수신 (attr, ' + Math.round(dataUrl.length/1024) + 'KB)');
        }
      }
    }
  });
  observer.observe(document.documentElement, { attributes: true });

  // content.js에서 직접 업로드 트리거
  document.addEventListener('uto-trigger-upload', function() {
    if (!window.__utoFileData) {
      console.log('[UtoGrok MAIN] ⚠️ 파일 데이터 없음');
      return;
    }
    console.log('[UtoGrok MAIN] ✓ 업로드 트리거 수신');
    
    const fi = document.querySelector('input[type="file"][name="files"]') || 
               document.querySelector('input[type="file"]');
    if (fi) {
      const dataUrl = window.__utoFileData;
      window.__utoFileData = null;
      
      fetch(dataUrl).then(r => r.blob()).then(blob => {
        const file = new File([blob], 'upload.png', { type: blob.type || 'image/png' });
        const dt = new DataTransfer();
        dt.items.add(file);
        Object.defineProperty(fi, 'files', { value: dt.files, writable: true, configurable: true });
        fi.dispatchEvent(new Event('change', { bubbles: true }));
        
        // React onChange
        const rk = Object.keys(fi).find(k => k.startsWith('__reactProps'));
        if (rk && fi[rk] && fi[rk].onChange) {
          fi[rk].onChange({ target: fi, currentTarget: fi, type: 'change', isTrusted: true });
          console.log('[UtoGrok MAIN] ✓ React onChange 호출!');
        }
        
        window.__utoFileReady = true;
        document.documentElement.setAttribute('data-uto-ready', 'yes');
        console.log('[UtoGrok MAIN] ✓ 직접 업로드 완료!');
      }).catch(e => console.error('[UtoGrok MAIN] ❌', e));
    } else {
      console.log('[UtoGrok MAIN] ⚠️ file input 없음');
    }
  });

  // file input click 가로채기
  const origClick = HTMLInputElement.prototype.click;
  
  HTMLInputElement.prototype.click = function() {
    if (this.type === 'file' && window.__utoFileData) {
      const dataUrl = window.__utoFileData;
      window.__utoFileData = null;
      
      console.log('[UtoGrok MAIN] ✓ file input click 가로챔!');
      
      fetch(dataUrl).then(r => r.blob()).then(blob => {
        const file = new File([blob], 'upload.png', { type: blob.type || 'image/png' });
        const dt = new DataTransfer();
        dt.items.add(file);
        Object.defineProperty(this, 'files', { value: dt.files, writable: true, configurable: true });
        this.dispatchEvent(new Event('change', { bubbles: true }));
        
        // React onChange 직접 호출
        const rk = Object.keys(this).find(k => k.startsWith('__reactProps'));
        if (rk && this[rk] && this[rk].onChange) {
          this[rk].onChange({ target: this, currentTarget: this, type: 'change', isTrusted: true });
          console.log('[UtoGrok MAIN] ✓ React onChange 호출!');
        }
        
        window.__utoFileReady = true;
        document.documentElement.setAttribute('data-uto-ready', 'yes');
        console.log('[UtoGrok MAIN] ✓ 업로드 완료!');
      }).catch(e => {
        console.error('[UtoGrok MAIN] ❌ 업로드 실패:', e);
        HTMLInputElement.prototype.click = origClick;
      });
      
      return;
    }
    origClick.call(this);
  };

  // showOpenFilePicker override
  if (window.showOpenFilePicker) {
    const origPicker = window.showOpenFilePicker.bind(window);
    window.showOpenFilePicker = async function() {
      if (window.__utoFileData) {
        const dataUrl = window.__utoFileData;
        window.__utoFileData = null;
        
        console.log('[UtoGrok MAIN] ✓ showOpenFilePicker 가로챔!');
        
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        const file = new File([blob], 'upload.png', { type: blob.type || 'image/png' });
        
        window.__utoFileReady = true;
        document.documentElement.setAttribute('data-uto-ready', 'yes');
        
        return [{ 
          getFile: async () => file, 
          name: file.name, 
          kind: 'file' 
        }];
      }
      return origPicker.apply(this, arguments);
    };
  }
})();
