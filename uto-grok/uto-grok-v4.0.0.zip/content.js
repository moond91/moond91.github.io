// ═══════════════════════════════════════════════
//  우토그록 Uto Grok — Content Script v4.0.0  (2026.09.09)
//  grok.com 편집 페이지(/imagine/post/) 신규 UI 대응
//   1) "동영상 만들기" → Add Prompt / Quick Animate 메뉴 경로로 영상 생성
//   2) 프롬프트 입력을 execCommand/paste 기반으로 교체 (tiptap 상태 반영)
//   3) 제출 후 "실제로 시작됐는지" 검증 + 100초 내 미시작 시 자동 재시도
//   4) 영상 길이/해상도 드롭다운 정식 지원, 종횡비 오클릭 차단
//   5) 작업 잠금 개선 — 앞 작업이 멈춰도 다음 이미지로 넘어감
//   6) UI 덤프 진단 로그 (실제 DOM 구조 확인용)
// ═══════════════════════════════════════════════
(()=>{
'use strict';

if (window.__UTOGROK_LISTENER__) return;
window.__UTOGROK_LISTENER__ = true;

let aborted = false;
let isProcessing = false; // ★ 실행 잠금

chrome.runtime.sendMessage({ type: 'TAB_READY' }).catch(()=>{});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('[UtoGrok] 메시지 수신:', msg.action);
  if (msg.action === 'GENERATE') {
    startKeepAlive(); // ★ 창 최소화 방지
    (async () => {
      // ★ FIX: 이전 작업이 멈춰 있으면 강제 중단하고 새 작업을 받는다
      //   (예전엔 여기서 'Already processing'으로 튕겨서 큐 전체가 막혔음)
      if (isProcessing) {
        log('⚠️ 이전 작업이 아직 실행 중 — 강제 중단하고 새 작업 시작');
        aborted = true;
        const t0 = Date.now();
        while (isProcessing && Date.now() - t0 < 6000) await wait(300);
        isProcessing = false;
      }
      isProcessing = true;
      aborted = false;
      try {
        const r = await handleGenerate(msg);
        sendResponse(r);
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      } finally {
        isProcessing = false;
      }
    })();
    return true;
  }
  if (msg.action === 'STOP') {
    aborted = true;
    isProcessing = false;
    sendResponse({ success: true });
  }
  if (msg.action === 'PING') {
    sendResponse({ ready: true });
  }
  if (msg.action === 'DIAG') {          // ★ 사이드패널에서 UI 진단 요청 가능
    dumpUI('수동 진단');
    sendResponse({ ok: true });
  }
});

function step(s) {
  try { chrome.runtime.sendMessage({ type: 'STEP_UPDATE', step: s }); } catch {}
}

// ═══════════════════════════════════════
//  MAIN: 매 생성마다 이 전체 흐름 실행
// ═══════════════════════════════════════
async function handleGenerate({ type, prompt, imageDataUrl, ratio, duration, quality, folder }) {
  log(`=== 새 작업 시작: ${type} ===`);
  if (prompt) log(`프롬프트: ${prompt.substring(0, 50)}...`);

  try {
    // ★ STEP 0: 완전 리셋 — 새로운 Imagine 입력 화면
    step('input');
    await resetToFreshImagine();
    log('✓ 리셋 완료');
    await wait(1000);

    if (aborted) throw new Error('Aborted');

    // ★ 후파 방식: 업로드 먼저 → 편집 페이지 이동 → 옵션 설정 → 전송

    // STEP 1: 이미지 업로드 (→ grok이 /imagine/post/<id>로 자동 이동)
    if (type === 'image' && imageDataUrl) {
      step('upload');
      await uploadSingleImage(imageDataUrl);
    }

    // ★ 클릭 전에 기존 영상을 먼저 마킹 — 이후 새로 생긴 video = 생성 시작 신호
    markExistingVideos();

    // STEP 2: 편집 페이지에서 비디오 모드 전환
    const modeInfo = await switchToVideoMode(!!prompt);
    log(`  경로: ${modeInfo.route}`);

    // STEP 3: 옵션 설정 (길이 / 해상도 / 비율)
    await applyVideoOptions({ duration, ratio, route: modeInfo.route });

    // STEP 4: 프롬프트 입력
    let promptTyped = false;
    if (prompt && modeInfo.route !== 'quick') {
      promptTyped = await typePrompt(prompt);
      await wait(400);
    } else {
      log('  ℹ️ 프롬프트 입력 생략');
    }

    if (aborted) throw new Error('Aborted');

    // STEP 5: 전송 + 시작 검증
    step('send');

    if (modeInfo.route === 'quick' || modeInfo.alreadyGenerating) {
      log('  ℹ️ 이미 생성이 시작됨 — 제출 생략');
    } else {
      await submitAndVerify({ promptTyped });
    }

    // STEP 6: 동영상 생성 대기
    //  ★ 1차는 100초만 기다린다 — 그 안에 영상이 없으면 "이미지가 생성된" 경우이므로
    //    우측 패널 "동영상 만들기" 경로로 자동 재시도한다 (5분 헛대기 방지)
    step('generate');
    let videoUrl;
    const firstTimeout = (modeInfo.route === 'quick' || modeInfo.alreadyGenerating) ? 300000 : 100000;
    try {
      videoUrl = await waitForVideo(firstTimeout);
    } catch (e) {
      if (!/시간 초과/.test(e.message) || aborted) throw e;
      log('⚠️ 영상이 안 나옴 (이미지가 생성된 듯) → "동영상 만들기" 경로로 자동 재시도');
      markExistingVideos();
      const retry = await switchToVideoMode(!!prompt);
      log(`  재시도 경로: ${retry.route}`);
      if (retry.route !== 'quick' && !retry.alreadyGenerating) {
        if (prompt) await typePrompt(prompt);
        await wait(400);
        await submitAndVerify({ promptTyped: !!prompt });
      }
      videoUrl = await waitForVideo(300000);
    }
    if (aborted) throw new Error('Aborted');

    // ★ STEP 7: 업스케일 (480p-upscale 또는 720p 선택 시)
    let finalVideoUrl = videoUrl;
    if (quality === '480p-upscale' || quality === '720p') {
      step('download');
      log('🔍 업스케일 시작...');
      const upscaledUrl = await doUpscale();
      if (upscaledUrl) finalVideoUrl = upscaledUrl;
    }

    // STEP 8: 다운로드
    if (quality && quality !== 'none' && finalVideoUrl) {
      step('download');
      await downloadToFolder(finalVideoUrl, prompt || 'video', folder);
    }

    step('done');
    log('✅ 작업 완료!');
    return { success: true, videoUrl };

  } catch (err) {
    step('error');
    log('❌ ' + err.message);
    dumpUI('실패 시점');
    return { success: false, error: err.message };
  }
}

// ═══════════════════════════════════════
//  ★★ FIX: 비디오 모드 전환 (연타 금지 + 상태 검증)
// ═══════════════════════════════════════
// ★ 실측 DOM 기준 (2026-09)
//   경로 A(정답): 하단 입력바의 세그먼트 컨트롤 [업로드][이미지][비디오][종횡비]
//                 → aria-label="비디오" 버튼을 눌러 비디오 모드로 전환 후 프롬프트+Enter
//   경로 B(폴백): 우측 패널 "동영상 만들기"는 드롭다운 트리거(state=closed→open)로,
//                 열면 "Add Prompt" / "Quick Animate" 메뉴가 나온다
const VIDEO_TOGGLE_LABELS = ['비디오', 'Video'];
const VIDEO_MENU_LABELS = ['동영상 만들기', '동영상만들기', 'Make video', 'Create video'];

async function switchToVideoMode(hasPrompt) {
  log('  비디오 모드 전환...');
  const before = snapshotButtons();
  dumpUI('① 편집 페이지 진입 직후', before);

  // ── 경로 B(기본): 우측 패널 "동영상 만들기" → Add Prompt / Quick Animate ──
  //    이 메뉴는 라벨이 명확해서 상태 추측이 필요 없다.
  //    하단 바의 [이미지]/[비디오] 세그먼트는 aria-pressed도 없고 배경색도 동일해서
  //    "지금 어느 모드인지" 알아낼 방법이 없다 → 그래서 기본 경로에서 제외.
  const menuBtn = findExactButton(VIDEO_MENU_LABELS) ||
                  visibleClickables().find(b => VIDEO_MENU_LABELS.some(L => txt(b).includes(L) || aria(b).includes(L)));

  if (menuBtn) {
    log('  ▶ 경로 B: 우측 패널 "동영상 만들기" 메뉴');
    if (menuBtn.getAttribute('data-state') !== 'open') {
      reactClick(menuBtn);
      log('  ✓ 드롭다운 열기');
    }

    const wanted = hasPrompt
      ? ['Add Prompt', '프롬프트 추가', '프롬프트 입력']
      : ['Quick Animate', '빠른 애니메이션', '바로 만들기'];
    const alt = hasPrompt
      ? ['Quick Animate', '빠른 애니메이션', '바로 만들기']
      : ['Add Prompt', '프롬프트 추가', '프롬프트 입력'];

    let picked = null, pickedLabel = '';
    for (let t = 0; t < 15; t++) {
      await wait(400);
      picked = findExactButton(wanted) || findMenuItem(wanted);
      if (picked) { pickedLabel = wanted[0]; break; }
      if (t > 8) {
        const fb = findExactButton(alt) || findMenuItem(alt);
        if (fb) { picked = fb; pickedLabel = alt[0]; break; }
      }
    }

    dumpDiff(before, '② "동영상 만들기" 드롭다운 열림');

    if (picked) {
      const edsBefore = new Set(listEditors());
      reactClick(picked);
      log(`  ✓ 메뉴 선택: "${pickedLabel}"`);
      await wait(2500);
      dumpDiff(before, `③ "${pickedLabel}" 클릭 후`);

      // Add Prompt로 새 입력창이 떴다면 그쪽을 타깃으로 지정
      document.querySelectorAll('[data-uto-target]').forEach(e => delete e.dataset.utoTarget);
      const fresh = listEditors().find(e => !edsBefore.has(e));
      if (fresh) {
        fresh.dataset.utoTarget = '1';
        log('  ✓ 새 프롬프트 입력창 감지 → 여기에 입력합니다');
      }

      const generating = generationStarted();
      if (generating) log('  ▶ 생성이 바로 시작됨');
      return {
        ok: true,
        route: /Quick|빠른|바로/.test(pickedLabel) ? 'quick' : 'menu-prompt',
        alreadyGenerating: generating,
      };
    }

    log('  ⚠️ Add Prompt / Quick Animate 항목 없음 → 메뉴 닫고 경로 A 시도');
    document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await wait(600);
  }

  // ── 경로 A(폴백): 하단 바 [비디오] 세그먼트 ──────────────
  //    현재 모드를 알 수 없으므로 "항상 한 번 클릭"한다 (라디오라 중복 클릭은 무해)
  let toggle = findExactButton(VIDEO_TOGGLE_LABELS);
  if (!toggle) {
    log('  ℹ️ 하단 바가 안 보임 → 입력창 클릭해서 펼치기');
    const ed = findVisibleEditor();
    if (ed) { reactClick(ed); ed.focus(); }
    for (let t = 0; t < 10 && !toggle; t++) {
      await wait(400);
      toggle = findExactButton(VIDEO_TOGGLE_LABELS);
    }
  }

  if (toggle) {
    const r = toggle.getBoundingClientRect();
    log(`  ▶ 경로 A: 하단 바 [비디오] 세그먼트 클릭 (pos=${Math.round(r.x)},${Math.round(r.y)})`);
    reactClick(toggle);
    await wait(1500);
    dumpDiff(before, '② [비디오] 세그먼트 클릭 후');
    return { ok: true, route: 'toggle', alreadyGenerating: false };
  }

  dumpDiff(before, '② 비디오 진입 버튼을 아예 찾지 못함');
  throw new Error('편집 페이지에서 "동영상 만들기"도 [비디오] 세그먼트도 찾지 못했습니다.');
}

function listEditors() {
  return [...document.querySelectorAll('[contenteditable="true"], textarea')].filter(isVisible);
}

// 텍스트 / aria-label / title 이 정확히 일치하는 보이는 버튼
function findExactButton(labels) {
  for (const L of labels) {
    for (const b of visibleClickables()) {
      if (txt(b) === L || aria(b) === L || (b.getAttribute('title') || '').trim() === L) return b;
    }
  }
  return null;
}

function findMenuItem(labels) {
  const items = [...document.querySelectorAll('[role="menuitem"], [role="option"], [data-radix-collection-item]')].filter(isVisible);
  for (const L of labels) {
    for (const it of items) if (txt(it) === L || txt(it).includes(L)) return it;
  }
  return null;
}

// ★ 생성이 실제로 시작됐는지 — 엄격 판정 (스켈레톤/펄스 애니메이션은 제외)
function generationStarted() {
  // 마킹 안 된 새 video 요소
  for (const v of document.querySelectorAll('video')) {
    if (!v.dataset._uto) return true;
  }
  // 진행바
  for (const p of document.querySelectorAll('[role="progressbar"]')) if (isVisible(p)) return true;
  // 명시적 문구
  const el = findByText(['생성 중', '생성중', '만드는 중', 'generating', 'processing'], 'div, span, p');
  return !!el;
}

// 비디오 모드인지 판단
function isVideoMode() {
  const btns = visibleClickables();

  // 1) 해상도/길이 버튼 (비디오 모드에서만 등장)
  const texts = btns.map(txt);
  if (['480p', '720p', '1080p', '6s', '10s', '15s'].some(t => texts.includes(t))) return true;

  // 2) [비디오] 세그먼트가 선택된 상태
  //    aria-pressed 가 없는 UI라 활성 스타일(class)까지 확인한다
  const vBtn = findExactButton(VIDEO_TOGGLE_LABELS);
  if (vBtn) {
    if (vBtn.getAttribute('aria-pressed') === 'true') return true;
    if (['on', 'active', 'checked'].includes(vBtn.getAttribute('data-state'))) return true;
    if (vBtn.getAttribute('aria-selected') === 'true') return true;
    if (isSegmentActive(vBtn)) return true;
  }

  // ⚠️ 우측 패널의 "동영상 만들기"(y≈941)를 제출버튼으로 오인하면 안 된다.
  //    v3.0.3에서 이 오탐 때문에 "이미 비디오 모드"로 착각하고 이미지가 생성됐음.

  // 3) 입력창 placeholder 변화
  const ed = findVisibleEditor();
  if (ed) {
    const ph = ((ed.getAttribute('aria-placeholder') || ed.getAttribute('placeholder') || ed.dataset.placeholder || '') + '').toLowerCase();
    if (/동영상|영상|비디오|video|motion|움직|animate/.test(ph)) return true;
  }

  return false;
}

// 세그먼트 컨트롤에서 [이미지] vs [비디오] 중 어느 쪽이 활성인지 배경색으로 판정
function isSegmentActive(el) {
  try {
    const bg = getComputedStyle(el).backgroundColor;
    if (!bg || bg === 'transparent' || /rgba\(0,\s*0,\s*0,\s*0\)/.test(bg)) return false;
    // 형제(=이미지 버튼)와 배경이 다르면 이쪽이 선택된 것
    const sib = [...(el.parentElement?.children || [])].filter(c => c !== el && c.tagName === el.tagName);
    for (const s of sib) {
      if (getComputedStyle(s).backgroundColor !== bg) return true;
    }
  } catch {}
  return false;
}

// 생성 진행중 표시(진행바/"생성 중")가 보이는지 — 스켈레톤/펄스는 오탐이라 제외
function isGeneratingIndicatorVisible() {
  for (const p of document.querySelectorAll('[role="progressbar"]')) if (isVisible(p)) return true;
  const el = findByText(['생성 중', '생성중', 'generating', 'creating', '만드는 중'], 'div, span, p');
  return !!el;
}

// 현재 화면의 클릭 가능 요소 시그니처 (UI가 바뀌었는지 판단용)
function uiSignature() {
  return visibleClickables()
    .map(b => `${txt(b)}|${aria(b)}|${b.getAttribute('data-state') || ''}`)
    .join('§');
}

function visibleClickables() {
  return [...document.querySelectorAll('button, [role="button"], [role="tab"], [role="radio"], [role="menuitem"]')]
    .filter(isVisible);
}

function txt(el) { return (el.textContent || '').trim(); }
function aria(el) { return (el.getAttribute('aria-label') || '').trim(); }

function isVisible(el) {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  if (r.width === 0 || r.height === 0) return false;
  const s = getComputedStyle(el);
  if (s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0') return false;
  return true;
}

// ★ 진단 도구 — 콘솔에 "복사 가능한 한 덩어리 텍스트"로 출력
function describeBtn(b) {
  const r = b.getBoundingClientRect();
  let bg = '';
  try { bg = getComputedStyle(b).backgroundColor; } catch {}
  return `text="${txt(b).substring(0, 30)}" aria="${aria(b)}" title="${b.getAttribute('title') || ''}"` +
    ` state="${b.getAttribute('data-state') || ''}" pressed="${b.getAttribute('aria-pressed') || ''}"` +
    ` disabled=${!!b.disabled} bg=${bg} pos=(${Math.round(r.x)},${Math.round(r.y)}) ${Math.round(r.width)}x${Math.round(r.height)}`;
}

function snapshotButtons() {
  return visibleClickables().map(describeBtn);
}

function inputsReport() {
  const eds = [...document.querySelectorAll('[contenteditable="true"], textarea, input[type="text"]')].filter(isVisible);
  const lines = eds.map((e, i) =>
    `  [${i}] <${e.tagName.toLowerCase()}> class="${(e.className || '').toString().substring(0, 60)}"` +
    ` placeholder="${e.getAttribute('aria-placeholder') || e.getAttribute('placeholder') || e.dataset.placeholder || ''}"` +
    ` text="${(e.textContent || e.value || '').substring(0, 40)}"`
  );
  return `— 입력창 ${eds.length}개\n` + (lines.join('\n') || '  (없음)') +
    `\n— video ${document.querySelectorAll('video').length}개 / progressbar ${document.querySelectorAll('[role="progressbar"]').length}개`;
}

function dumpUI(label, snap) {
  try {
    const list = snap || snapshotButtons();
    console.log(
      `[UtoGrok] 🔍 UI 덤프 — ${label}\nURL: ${location.pathname}\n버튼 ${list.length}개\n` +
      list.map((s, i) => `[${i}] ${s}`).join('\n') + '\n' + inputsReport()
    );
  } catch (e) { log('UI 덤프 실패: ' + e.message); }
}

// ★ 클릭 전/후 차이만 출력 — 무엇이 생기고 사라졌는지가 핵심 단서
function dumpDiff(beforeList, label) {
  try {
    const after = snapshotButtons();
    const bSet = new Set(beforeList), aSet = new Set(after);
    const added = after.filter(s => !bSet.has(s));
    const removed = beforeList.filter(s => !aSet.has(s));
    console.log(
      `[UtoGrok] 🔍 UI 변화 — ${label}\n` +
      `버튼 ${beforeList.length} → ${after.length}\n` +
      `➕ 새로 생김 (${added.length}개)\n` + (added.map(s => '  + ' + s).join('\n') || '  (없음)') + '\n' +
      `➖ 사라짐 (${removed.length}개)\n` + (removed.map(s => '  - ' + s).join('\n') || '  (없음)') + '\n' +
      inputsReport()
    );
  } catch (e) { log('UI diff 실패: ' + e.message); }
}

// ═══════════════════════════════════════
//  옵션 (길이 / 해상도 / 비율)
// ═══════════════════════════════════════
//  실측: Add Prompt 후 하단 바에 나타나는 옵션들
//    aria="동영상 길이"   text="6s"    (드롭다운, state=closed)
//    aria="비디오 해상도" text="480p"  (드롭다운)
//    aria="비디오 오디오" pressed=true (토글)
//    aria="동영상 만들기" (제출 버튼, 기존 aria="편집"을 대체)
async function applyVideoOptions({ duration, ratio, route }) {
  if (duration) {
    const want = String(duration).replace('-concat', '') + 's';
    await selectFromDropdown(['동영상 길이', 'Video length', '비디오 길이'], want);
  }

  // ⚠️ 비디오 모드에서는 하단 바의 종횡비 버튼이 사라진다 (영상은 원본 이미지 비율을 그대로 씀).
  //    이때 "종횡비"로 검색하면 우측 패널의 이미지 종횡비 버튼이 잡혀서
  //    엉뚱하게 원본 이미지를 잘라버릴 수 있다 → 비디오 경로에서는 건드리지 않는다.
  if (ratio && route !== 'menu-prompt' && route !== 'quick') {
    await selectFromDropdown(['종횡비', 'Aspect ratio'], ratio);
  } else if (ratio) {
    log('  ℹ️ 종횡비는 원본 이미지 비율을 따름 (건너뜀)');
  }
}

// 드롭다운 버튼(트리거)을 열고 원하는 항목을 고른다.
// ⚠️ 이 버튼들은 "클릭하면 선택"이 아니라 "클릭하면 메뉴가 열리는" 트리거다.
// ⚠️ 하단 입력바에 있는 것만 대상으로 한다 (우측 편집 패널의 동명 버튼 오클릭 방지)
async function selectFromDropdown(ariaLabels, wantText) {
  const ed = findVisibleEditor();
  const edTop = ed ? ed.getBoundingClientRect().top : null;

  const trigger = visibleClickables().find(b => {
    if (!ariaLabels.includes(aria(b))) return false;
    if (edTop === null) return true;
    return Math.abs(b.getBoundingClientRect().top - edTop) < 60; // 입력창과 같은 줄
  });
  if (!trigger) { log(`  ℹ️ 옵션 없음: ${ariaLabels[0]}`); return false; }

  if (txt(trigger) === wantText) { log(`  옵션 이미 ${ariaLabels[0]}=${wantText}`); return true; }

  reactClick(trigger);
  for (let t = 0; t < 14; t++) {
    await wait(300);
    const item = [...document.querySelectorAll('[role="menuitem"], [role="option"], [role="menuitemradio"], [data-radix-collection-item]')]
      .filter(isVisible)
      .find(i => txt(i) === wantText || txt(i).startsWith(wantText));
    if (item) {
      reactClick(item);
      await wait(500);
      log(`  옵션: ${ariaLabels[0]} → ${wantText}`);
      return true;
    }
  }

  log(`  ⚠️ 옵션 항목 못찾음: ${ariaLabels[0]}=${wantText} — 메뉴 닫고 진행`);
  document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await wait(400);
  return false;
}

// ═══════════════════════════════════════
//  ★ Imagine 새 입력 페이지로 이동
// ═══════════════════════════════════════
async function goBackToInput() {
  log('⬅️ Imagine 새 페이지로...');

  const allLinks = document.querySelectorAll('a, button, div[role="button"]');
  for (const el of allLinks) {
    const t = txt(el);
    if (t === '새로운 생성' || t === 'New Generation' || t === 'New generation') {
      if (isVisible(el)) {
        el.removeAttribute('target');
        reactClick(el);
        log('  ✓ "새로운 생성" 클릭');
        await wait(4000);
        await waitForEl('div.ProseMirror[contenteditable="true"], div[contenteditable="true"], div.tiptap', 15000);
        await wait(3000);
        document.querySelectorAll('[data-_uto]').forEach(e => delete e.dataset._uto);
        return;
      }
    }
  }

  log('  ⚠️ "새로운 생성" 못찾음 → 페이지 새로고침');
  window.location.href = 'https://grok.com/imagine';
  await wait(6000);
  await waitForEl('div.ProseMirror[contenteditable="true"], div[contenteditable="true"], div.tiptap', 15000);
  await wait(3000);
  document.querySelectorAll('[data-_uto]').forEach(e => delete e.dataset._uto);
}

// ═══════════════════════════════════════
//  ★ 리셋: 입력 화면 준비
// ═══════════════════════════════════════
async function resetToFreshImagine() {
  log('🔄 리셋...');

  // 편집 페이지(/imagine/post/)에 남아있으면 무조건 새 입력 페이지로
  if (/\/imagine\/post\//.test(location.pathname)) {
    log('  편집 페이지에 있음 → Imagine 이동');
    await goBackToInput();
    await wait(500);
  }

  const editor = findVisibleEditor();
  if (!editor) {
    log('  입력 화면 아님 → Imagine 이동');
    await goBackToInput();
    await wait(500);
  }

  document.querySelectorAll('[data-_uto]').forEach(el => delete el.dataset._uto);
  document.querySelectorAll('[data-uto-target]').forEach(el => delete el.dataset.utoTarget);

  await removeAttachedImages();
  await wait(300);

  const ed = findVisibleEditor();
  if (ed && ed.isContentEditable) {
    ed.focus();
    await wait(100);
    ed.innerHTML = '<p></p>';
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  }

  log('  ✓ 입력 초기화 완료');
}

// 첨부된 이미지 썸네일들 제거
async function removeAttachedImages() {
  let removed = 0;
  for (let attempt = 0; attempt < 20; attempt++) {
    const selectors = [
      'button[aria-label*="삭제"]', 'button[aria-label*="Remove"]', 'button[aria-label*="remove"]',
      'button[aria-label*="Close"]', 'button[aria-label*="close"]', 'button[aria-label*="취소"]',
      'button[aria-label*="Delete"]', 'button[aria-label*="delete"]',
    ];

    let found = false;
    for (const sel of selectors) {
      for (const btn of document.querySelectorAll(sel)) {
        const rect = btn.getBoundingClientRect();
        if (rect.width > 0 && rect.width < 40 && rect.height > 0 && rect.y > window.innerHeight * 0.4) {
          btn.click(); removed++; found = true; await wait(400); break;
        }
      }
      if (found) break;
    }

    if (!found) {
      const inputArea = document.querySelector('[class*="query-bar"]') ||
                        document.querySelector('div.ProseMirror')?.parentElement?.parentElement;
      if (inputArea) {
        for (const img of inputArea.querySelectorAll('img')) {
          const r = img.getBoundingClientRect();
          if (r.width > 0 && r.width < 100) {
            const closeBtn = (img.closest('div') || img.parentElement)?.querySelector('button');
            if (closeBtn) { closeBtn.click(); removed++; found = true; await wait(400); break; }
          }
        }
      }
    }

    if (!found) break;
  }
  if (removed > 0) log(`  첨부 이미지 ${removed}개 제거`);
}

// ═══════════════════════════════════════
//  ★ 업스케일: ... 메뉴 → 동영상 업스케일
// ═══════════════════════════════════════
async function doUpscale() {
  try {
    const moreBtn = findMoreOptionsButton();
    if (!moreBtn) { log('  ⚠️ ... 더보기 버튼 못찾음 — 업스케일 건너뜀'); return null; }

    reactClick(moreBtn);
    log('  ✓ 추가 옵션 클릭 (React 호환)');

    let upscaleItem = null;
    for (let retry = 0; retry < 16; retry++) {
      await wait(500);
      const allItems = document.querySelectorAll('[role="menuitem"]');
      if (retry === 0) {
        log(`  role=menuitem ${allItems.length}개 발견`);
        allItems.forEach((item, i) => log(`    [${i}] "${txt(item).substring(0, 30)}"`));
      }
      for (const item of allItems) {
        const text = txt(item);
        if (text.includes('업스케일') || text.includes('Upscale')) {
          upscaleItem = item; log(`  ✓ 업스케일 찾음! (retry ${retry}): "${text}"`); break;
        }
      }
      if (upscaleItem) break;
      if (retry === 4) { log('  ⚠️ 4회 실패 → 재클릭'); reactClick(moreBtn); }
    }

    if (!upscaleItem) {
      log('  ⚠️ 동영상 업스케일 메뉴 못찾음 — 건너뜀');
      document.body.click(); await wait(300); return null;
    }

    reactClick(upscaleItem);
    log('  ✓ 동영상 업스케일 클릭');
    await wait(2000);

    log('  ⏳ 업스케일 대기...');
    const upscaledUrl = await waitForUpscaleComplete();
    if (upscaledUrl) { log('  ✓ 업스케일 완료!'); return upscaledUrl; }
    log('  ℹ️ 업스케일 URL 감지 못함 — 원본으로 진행');
    return null;
  } catch (e) {
    log('  ⚠️ 업스케일 오류: ' + e.message);
    return null;
  }
}

function findMoreOptionsButton() {
  const exact = document.querySelector('button[aria-label="추가 옵션"]');
  if (exact) return exact;
  const byLabel = document.querySelector('button[aria-label="More options"], button[aria-label="더보기"], button[aria-label="More"]');
  if (byLabel) return byLabel;
  const svgBtn = document.querySelector('button svg.lucide-ellipsis');
  if (svgBtn) return svgBtn.closest('button');
  return null;
}

async function waitForUpscaleComplete(timeout = 120000) {
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;
    const poll = setInterval(() => {
      if (done || aborted) { clearInterval(poll); resolve(null); return; }
      if (Date.now() - start > timeout) {
        done = true; clearInterval(poll); log('  ⚠️ 업스케일 타임아웃 (2분)'); resolve(null); return;
      }
      const successEl = findByText(
        ['업스케일 완료', 'Upscale complete', 'upscaled', '완료'],
        '[class*="toast"], [class*="alert"], [class*="notification"], [role="alert"]'
      );
      if (successEl) {
        done = true; clearInterval(poll);
        const vids = document.querySelectorAll('video');
        for (let i = vids.length - 1; i >= 0; i--) {
          const src = vids[i].src || vids[i].querySelector('source')?.src;
          if (src) { resolve(src); return; }
        }
        resolve(null); return;
      }
      const vids = document.querySelectorAll('video');
      for (let i = vids.length - 1; i >= 0; i--) {
        const src = vids[i].src || vids[i].querySelector('source')?.src;
        if (src && !vids[i].dataset._utoUpscaled) {
          vids[i].dataset._utoUpscaled = '1';
          done = true; clearInterval(poll); resolve(src); return;
        }
      }
    }, 2000);
  });
}

// ═══════════════════════════════════════
//  이미지 1개만 업로드
// ═══════════════════════════════════════
async function uploadSingleImage(dataUrl) {
  log('📎 이미지 업로드...');
  const file = toFile(dataUrl, 'upload_image.png');

  const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
  let fi = null;
  for (const inp of inputs) {
    const accept = (inp.accept || '').toLowerCase();
    if (accept.includes('image') || accept === '' || accept === '*' || accept === '*/*') { fi = inp; break; }
  }
  if (!fi) fi = inputs[0];
  if (!fi) { log('  ❌ file input을 찾을 수 없음'); return; }

  const dt = new DataTransfer();
  dt.items.add(file);
  fi.files = dt.files;
  fi.dispatchEvent(new Event('change', { bubbles: true }));
  fi.dispatchEvent(new Event('input', { bubbles: true }));
  log('  ✓ file input 설정 완료');
  await wait(500);

  log('  ⏳ 편집 페이지 이동 대기...');
  const editOk = await waitForEditPage();
  if (!editOk) throw new Error('편집 페이지(/imagine/post/) 이동 실패 — 업로드가 안 됐을 수 있습니다');
  log('  ✓ 편집 페이지 진입! (' + location.pathname + ')');
}

async function waitForEditPage() {
  const maxMs = 30000;
  const start = Date.now();
  while (Date.now() - start < maxMs) {
    if (/\/imagine\/post\//.test(location.pathname)) {
      await wait(2000); // UI 렌더 대기 (편집 툴바가 늦게 뜸)
      return true;
    }
    await wait(400);
  }
  return /\/imagine\/post\//.test(location.pathname);
}

// ═══════════════════════════════════════
//  ★★ FIX: 프롬프트 입력 (tiptap/ProseMirror 상태까지 반영)
// ═══════════════════════════════════════
function findVisibleEditor() {
  // "Add Prompt"로 새로 뜬 입력창이 지정돼 있으면 그것을 우선
  const target = document.querySelector('[data-uto-target]');
  if (target && isVisible(target)) return target;

  const cands = [
    ...document.querySelectorAll('div.tiptap[contenteditable="true"]'),
    ...document.querySelectorAll('div.ProseMirror[contenteditable="true"]'),
    ...document.querySelectorAll('[contenteditable="true"]'),
    ...document.querySelectorAll('textarea'),
  ].filter(isVisible);

  if (!cands.length) return null;
  // 화면에서 가장 큰(=실제 입력창) 요소 선택, 중복 제거
  const uniq = [...new Set(cands)];
  return uniq.sort((a, b) => {
    const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
    return (rb.width * rb.height) - (ra.width * ra.height);
  })[0];
}

async function typePrompt(text) {
  if (!text) return false;

  const el = findVisibleEditor();
  if (!el) { log('  ⚠️ 프롬프트 입력창을 찾을 수 없음 — 프롬프트 없이 진행'); return false; }

  // 캐럿을 확실히 입력창 안에 두기 위해 실제 클릭 흉내
  reactClick(el);
  el.focus();
  await wait(150);

  const ok = await insertText(el, text);
  if (ok) {
    log(`  프롬프트 입력 완료: "${text.substring(0, 40)}${text.length > 40 ? '...' : ''}"`);
    return true;
  }
  log('  ⚠️ 프롬프트 입력 실패 (모든 방식 실패)');
  return false;
}

async function insertText(el, text) {
  // ── textarea / input ────────────────────────────
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return (el.value || '').includes(text.substring(0, 8));
  }

  // ── contenteditable (tiptap / ProseMirror) ──────
  const probe = text.substring(0, 8);

  // 방법 1: 전체 선택 후 execCommand insertText
  //   → beforeinput/input 이 네이티브로 발생해 ProseMirror 내부 상태가 갱신됨
  try {
    selectAllIn(el);
    document.execCommand('insertText', false, text);
    await wait(200);
    if ((el.textContent || '').includes(probe)) return true;
  } catch {}

  // 방법 2: paste 이벤트 (ProseMirror는 paste 핸들러를 가짐)
  try {
    selectAllIn(el);
    const dt = new DataTransfer();
    dt.setData('text/plain', text);
    el.dispatchEvent(new ClipboardEvent('paste', {
      clipboardData: dt, bubbles: true, cancelable: true, composed: true
    }));
    await wait(250);
    if ((el.textContent || '').includes(probe)) return true;
  } catch {}

  // 방법 3: beforeinput + DOM 직접 수정 + input (최후 폴백)
  try {
    el.dispatchEvent(new InputEvent('beforeinput', {
      inputType: 'insertText', data: text, bubbles: true, cancelable: true, composed: true
    }));
    const p = el.querySelector('p');
    if (p) p.textContent = text; else el.textContent = text;
    el.dispatchEvent(new InputEvent('input', {
      inputType: 'insertText', data: text, bubbles: true, composed: true
    }));
    await wait(200);
    if ((el.textContent || '').includes(probe)) return true;
  } catch {}

  return false;
}

function selectAllIn(el) {
  const sel = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(el);
  sel.removeAllRanges();
  sel.addRange(range);
}

// ═══════════════════════════════════════
//  ★★ FIX: 제출 + "정말 시작됐는지" 검증
// ═══════════════════════════════════════
function markExistingVideos() {
  document.querySelectorAll('video').forEach(v => v.dataset._uto = '1');
  document.querySelectorAll('a[href*=".mp4"], a[download]').forEach(a => a.dataset._uto = '1');
  log('  ✓ 기존 영상 마킹 완료');
}

function snapshotState() {
  const ed = findVisibleEditor();
  return {
    url: location.href,
    videos: document.querySelectorAll('video').length,
    editorText: ed ? (ed.textContent || ed.value || '').trim() : '',
    generating: isGeneratingIndicatorVisible(),
    sig: uiSignature(),
  };
}

function submissionStarted(before) {
  const now = snapshotState();
  if (now.url !== before.url) { log('  ✓ 시작 감지: URL 변경'); return true; }
  if (now.videos > before.videos) { log('  ✓ 시작 감지: video 요소 추가'); return true; }
  if (before.editorText && !now.editorText) { log('  ✓ 시작 감지: 입력창 비워짐'); return true; }
  if (!before.generating && now.generating) { log('  ✓ 시작 감지: 생성중 표시'); return true; }
  return false;
}

async function submitAndVerify({ promptTyped }) {
  const before = snapshotState();

  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt === 0) {
      pressEnterOnEditor();
      log('  ✓ Enter 전송 (1차)');
    } else {
      const btn = findSubmitBtn();
      if (btn) {
        reactClick(btn);
        log(`  ✓ 제출 버튼 클릭 (${attempt + 1}차) aria="${aria(btn)}" text="${txt(btn)}"`);
      } else {
        pressEnterOnEditor();
        log(`  ✓ Enter 재전송 (${attempt + 1}차) — 제출 버튼 못찾음`);
      }
    }

    // 최대 8초 관찰
    for (let i = 0; i < 16; i++) {
      if (aborted) throw new Error('Aborted');
      await wait(500);
      if (submissionStarted(before)) return true;
    }
    log(`  ⚠️ ${attempt + 1}차 제출 후 반응 없음`);
  }

  dumpUI('제출 실패');
  throw new Error(
    '제출해도 생성이 시작되지 않았습니다.' +
    (promptTyped ? '' : ' (프롬프트 입력이 실패했을 수 있음)') +
    ' 콘솔의 UI 덤프를 확인하세요.'
  );
}

function pressEnterOnEditor() {
  const el = findVisibleEditor();
  if (!el) { log('  ⚠️ 입력창 없음 (Enter 불가)'); return; }
  el.focus();
  // 캐럿을 텍스트 끝으로
  try {
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
  } catch {}
  const opts = {
    key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
    bubbles: true, cancelable: true, composed: true
  };
  el.dispatchEvent(new KeyboardEvent('keydown', opts));
  el.dispatchEvent(new KeyboardEvent('keypress', opts));
  el.dispatchEvent(new KeyboardEvent('keyup', opts));
}

// ★ 전송 버튼 찾기
function findSubmitBtn() {
  // 0) 하단 입력바에서 입력창과 같은 줄, 오른쪽에 있는 제출 버튼
  //    비디오 모드에서는 aria="동영상 만들기", 이미지 모드에서는 aria="편집"
  //    ⚠️ 우측 패널의 "동영상 만들기"(y≈941)와 헷갈리면 안 되므로 입력창 기준으로 고른다
  const ed0 = findVisibleEditor();
  if (ed0) {
    const er = ed0.getBoundingClientRect();
    for (const b of visibleClickables()) {
      if (b.disabled) continue;
      if (!/^(동영상 만들기|편집|제출|전송|Submit|Send|Create video)$/.test(aria(b))) continue;
      const r = b.getBoundingClientRect();
      if (Math.abs(r.top - er.top) < 140 && r.left > er.left) return b;
    }
  }

  // 1) 명시적 라벨
  const labeled = [
    'button[aria-label="제출"]', 'button[aria-label="Submit"]', 'button[aria-label="Send"]',
    'button[aria-label="전송"]', 'button[aria-label="생성"]', 'button[aria-label="만들기"]',
    'button[type="submit"]', 'button[data-testid="send-button"]',
  ];
  for (const sel of labeled) {
    const b = document.querySelector(sel);
    if (b && !b.disabled && isVisible(b)) return b;
  }

  // 2) 라벨 부분 일치
  const kws = ['send', 'submit', 'generate', '전송', '제출', '보내기', '생성', '만들기'];
  for (const b of visibleClickables()) {
    if (b.disabled) continue;
    const a = aria(b).toLowerCase(), t = (b.getAttribute('title') || '').toLowerCase();
    if (kws.some(k => a.includes(k) || t.includes(k))) return b;
  }

  // 3) 입력창 오른쪽의 아이콘 버튼 (텍스트 없음 + svg)
  const ed = findVisibleEditor();
  if (!ed) return null;
  const pr = ed.getBoundingClientRect();
  let best = null, bestDist = Infinity;
  for (const b of visibleClickables()) {
    if (b.disabled) continue;
    if (txt(b).length > 3) continue;              // 16:9, 480p 등 설정 버튼 제외
    if (!b.querySelector('svg')) continue;
    const br = b.getBoundingClientRect();
    if (br.left < pr.right - 80) continue;        // 입력창 오른쪽에 있는 것만
    if (Math.abs(br.top - pr.top) > 200) continue;
    const dist = Math.hypot(br.left - pr.right, br.top - pr.top);
    if (dist < bestDist) { bestDist = dist; best = b; }
  }
  return best;
}

// ═══════════════════════════════════════
//  동영상 생성 대기
// ═══════════════════════════════════════
async function waitForVideo(timeout = 300000) {
  log('⏳ 동영상 대기...');

  return new Promise((resolve, reject) => {
    const start = Date.now();
    let done = false;
    let lastLog = 0;

    const finish = (fn, arg) => {
      if (done) return; done = true;
      obs.disconnect(); clearInterval(poll); fn(arg);
    };

    const obs = new MutationObserver(() => {
      if (done) return;
      if (aborted) return finish(reject, new Error('Aborted'));
      const v = findNewVideo();
      if (v) { log('  ✓ 동영상 감지!'); finish(resolve, v); }
    });
    obs.observe(document.body, {
      childList: true, subtree: true, attributes: true,
      attributeFilter: ['src', 'href', 'data-state']
    });

    const poll = setInterval(() => {
      if (done) return;
      if (aborted) return finish(reject, new Error('Aborted'));

      const elapsed = Math.floor((Date.now() - start) / 1000);
      if (elapsed - lastLog >= 20) {
        lastLog = elapsed;
        log(`  ⏳ 생성 중... (${elapsed}초) video=${document.querySelectorAll('video').length} 진행표시=${isGeneratingIndicatorVisible()}`);
        // 45초가 지나도 생성 신호가 전혀 없으면 한 번 UI를 덤프해서 원인을 남긴다
        if (elapsed >= 40 && elapsed < 60 && !isGeneratingIndicatorVisible() && document.querySelectorAll('video').length === 0) {
          dumpUI('③ 40초 경과 — 생성 신호 없음');
        }
      }

      if (Date.now() - start > timeout) {
        dumpUI('동영상 타임아웃');
        return finish(reject, new Error('동영상 생성 시간 초과 (5분)'));
      }

      const errEl = findByText(
        ['error', 'failed', '오류', '실패', 'rate limit', 'try again'],
        '[class*="error"], [class*="alert"], [role="alert"]'
      );
      if (errEl) {
        return finish(reject, new Error('생성 오류: ' + txt(errEl).substring(0, 100)));
      }

      const v = findNewVideo();
      if (v) { log('  ✓ 동영상 감지 (poll)'); finish(resolve, v); }
    }, 2000);
  });
}

function findNewVideo() {
  const vids = document.querySelectorAll('video');
  for (let i = vids.length - 1; i >= 0; i--) {
    const v = vids[i], src = v.currentSrc || v.src || v.querySelector('source')?.src;
    if (src && !v.dataset._uto) {
      // 실제 재생 가능한 상태인지 확인 (빈 placeholder 방지)
      if (v.readyState >= 2 || v.duration > 0 || src.startsWith('http')) {
        v.dataset._uto = '1';
        return src;
      }
    }
  }
  const links = document.querySelectorAll('a[href*=".mp4"], a[download]');
  for (let i = links.length - 1; i >= 0; i--) {
    const a = links[i];
    if (!a.dataset._uto) { a.dataset._uto = '1'; return a.href; }
  }
  return null;
}

// ═══════════════════════════════════════
//  하위폴더 다운로드
// ═══════════════════════════════════════
async function downloadToFolder(url, prompt, folder) {
  const slug = (prompt || 'video').substring(0, 40)
    .replace(/[^a-zA-Z0-9가-힣\s]/g, '').replace(/\s+/g, '_').toLowerCase() || 'video';
  const ts = new Date().toISOString().slice(0, 16).replace(/[:-]/g, '');
  const filename = `${folder || 'grok-video'}/${ts}_${slug}.mp4`;

  log(`  📥 다운로드: ${filename}`);

  let downloadUrl = url;
  if (url.startsWith('blob:')) {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      downloadUrl = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(blob);
      });
      log('  ✓ blob → data URL 변환');
    } catch (e) {
      log('  ⚠️ blob 변환 실패: ' + e.message);
    }
  }

  chrome.runtime.sendMessage({ type: 'DOWNLOAD_VIDEO', url: downloadUrl, filename }, (resp) => {
    if (resp?.success) log('  ✓ 다운로드 시작!');
    else log('  ⚠️ 다운로드 응답: ' + JSON.stringify(resp));
  });
  await wait(3000);
}

// ═══════════════════════════════════════
//  유틸리티
// ═══════════════════════════════════════
function findByText(texts, selector) {
  for (const el of document.querySelectorAll(selector)) {
    const et = (el.textContent || '').trim().toLowerCase();
    const al = (el.getAttribute('aria-label') || '').toLowerCase();
    for (const t of texts) {
      const tl = t.toLowerCase();
      if (et === tl || et.includes(tl) || al.includes(tl)) {
        if (isVisible(el)) return el;
      }
    }
  }
  return null;
}

async function waitForEl(selector, timeout = 10000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const el = document.querySelector(selector);
    if (el) return el;
    await wait(500);
  }
  return null;
}

function toFile(dataUrl, name) {
  const [h, d] = dataUrl.split(',');
  const mime = h.match(/:(.*?);/)[1];
  const bin = atob(d);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new File([arr], name, { type: mime });
}

// ★ Web Worker 기반 타이머 (창 최소화해도 안 느려짐)
const _wb = new Blob([`self.onmessage=function(e){setTimeout(function(){self.postMessage('done')},e.data)}`], { type: 'application/javascript' });
const _wu = URL.createObjectURL(_wb);
function wait(ms) {
  return new Promise(resolve => {
    try {
      const w = new Worker(_wu);
      w.onmessage = () => { w.terminate(); resolve(); };
      w.postMessage(ms);
    } catch { setTimeout(resolve, ms); }
  });
}
function log(msg) { console.log(`[UtoGrok] ${msg}`); }

/**
 * ★ React 호환 클릭 — grok.com은 React 기반이라
 * 단순 .click()이나 MouseEvent만으로는 핸들러가 트리거되지 않음.
 */
function reactClick(el) {
  const rect = el.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window, composed: true };
  try { el.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch {}
  el.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerId: 1 }));
  el.dispatchEvent(new PointerEvent('pointerenter', { ...opts, pointerId: 1 }));
  el.dispatchEvent(new MouseEvent('mouseover', opts));
  el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerId: 1, isPrimary: true, button: 0 }));
  el.dispatchEvent(new MouseEvent('mousedown', { ...opts, button: 0 }));
  try { el.focus(); } catch {}
  el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerId: 1, isPrimary: true, button: 0 }));
  el.dispatchEvent(new MouseEvent('mouseup', { ...opts, button: 0 }));
  el.dispatchEvent(new MouseEvent('click', { ...opts, button: 0, detail: 1 }));
  // ⚠️ el.click() 은 호출하지 않는다 — 토글 버튼이 두 번 눌려 원상복귀됨
}

log('Content script v4.0.0 ✅');

// ★ 창 최소화해도 멈추지 않게 무음 오디오 재생
let keepAliveStarted = false;
function startKeepAlive() {
  if (keepAliveStarted) return;
  try {
    const ctx = new AudioContext();
    if (ctx.state === 'suspended') ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.value = 0.00001;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    keepAliveStarted = true;
    log('🔊 Keep-alive 활성화 (창 최소화 지원)');
  } catch (e) { log('⚠️ Keep-alive 실패: ' + e.message); }
}
document.addEventListener('click', () => startKeepAlive(), { once: true });
})();
